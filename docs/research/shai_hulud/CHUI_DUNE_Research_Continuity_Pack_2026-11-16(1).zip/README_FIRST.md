# PROJECT DUNE / SHAI-HULUD — Read me first

**Snapshot:** 16 November 2026. This is a continuity guide, not a scientific proof or production implementation.

## Core project decision

SHAI-HULUD is CHUÍ's ambitious, opt-in experimental **mathematical numerical method**, **not** a supervisor that merely selects established solvers. Its long-term target is a compatible scheme for the evolution of physical fields and adaptation of their numerical representation: Hamiltonian/Poisson dynamics, initially cold phase-space sheets, optimal-transport-guided sampling, and eventually suitable GENERIC/metriplectic irreversible physics. SPICE provides reusable mathematical operators and contracts; IX builds Laguerre/OT geometry; LITTLE MAKER handles local adaptation; ARRAKIS supplies geometric domain infrastructure; other DUNE modules add remapping, prediction, adjoints, optimization, testing, and uncertainty quantification.

## Current *actual* research milestone

Focus **only on structure-aware adaptive phase-space sheets** before attempting the full DUNE family. For collisionless matter, Hamiltonian evolution always underlies sheets and particles; *sheet vs particle* is a representation decision, not *sheet vs Hamiltonian*.

- **Fable archive:** 31-page manuscript and Python prototypes of **action-aware remapping**. Reported strong normal-error/action-period results for 1D sheets; local generating-function constructions in 2D/4D before shell crossing. No self-gravity, globally compatible chart gluing across caustics, or unrestricted stability proof.
- **DeepSeek archive:** Independent draft audit and seven scripts. Restricted theorem: nonnegative linear averaging/coarsening cannot preserve the standard discrete mass-weighted symplectic form except copying/permutation. Exact kinetic-energy variance identity. Nontrivial two-form defect tests; graded exact-node sampling helps, but reconstructing from an old approximation may make errors worse. A GENERIC oscillator correction was tested.
- **Compatibility:** These two works concern **different** operators. DeepSeek's no-go is *not* a disproof of Fable's generating-function reconstruction, but Fable's period preservation is *not* a proof of global nodal symplecticity.
- **Known mathematical issue:** The Fable monitor exponent $d/(d+3)$ is inconsistent with the actual written functional $\int\|C\|h^{3-d}\,dq$ and constraint $\int h^{-d}=N$. Re-derive the objective before using the monitor in 3D.

## Best next assignment

1. Correct the action/defect monitor derivation and independently audit both proof ledgers.
2. Compare action-corrected and conventional remapping **on the same exact/evolving reference problem**, with equal resolution, same time integrator, same error norms, measured runtime, action periods, mass and full geometry error.
3. Investigate global matching of local generating-function charts across a 2D fold caustic, and separate orientation/caustics from symplectic two-form defects.
4. Test 3D tetrahedral defect identities. Only after these gates, construct a self-consistent gravitational sheet solver.

## Where to find everything

The long reference is `SHAI_HULUD_Project_Dossier_2026-11-16.md` (also a PDF). Exact unmodified research sources are `original_sources/shai_hulud.zip` (Fable) and `original_sources/shai-hulud-lab(2).zip` (DeepSeek); the discussion archive is `original_sources/chatgpt-export-2026-11-16T11-58-15-556Z.zip`.

**Always distinguish:** continuous reparameterization, discrete reconstruction, positive averaging, physical dissipation, and a full finite-dimensional symplectic map. Preserve negative results. Do not declare novelty or CHUÍ performance improvement without independent proof and matched baselines.
