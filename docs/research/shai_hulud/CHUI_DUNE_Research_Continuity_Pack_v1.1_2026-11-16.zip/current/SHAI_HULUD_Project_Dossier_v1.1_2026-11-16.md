---
title: "PROJECT DUNE | SHAI-HULUD"
subtitle: "Master Research Dossier v1.1 | Post-Breakthrough Architecture"
author: "CHUÍ Experimental Numerical Research Programme — working scientific record"
date: "16 November 2026 (Brazil local time)"
lang: en-US
geometry:
  - a4paper
  - margin=20mm
fontsize: 10pt
colorlinks: true
linkcolor: "243B53"
urlcolor: "1769AA"
toc: true
toc-depth: 2
header-includes: |
  \usepackage{longtable}
  \usepackage{booktabs}
  \usepackage{microtype}
  \usepackage{xurl}
  \setlength{\emergencystretch}{3em}
---

> **Research status: DESIGN + NUMERICAL PROTOTYPES. NOT PEER REVIEWED.** This is the authoritative **v1.1** project record. It supersedes the *priorities and performance expectations* of the 16 November v1.0 dossier; it does not erase historical hypotheses or the original source archives. Distinguish *established mathematical principles*, *agent-authored proof claims*, *recorded/reproduced tests*, *proposals*, and *open research*. Numerical results come from the supplied Fable/DeepSeek archives unless explicitly indicated otherwise.

# Read this first — the updated continuity capsule

**Identity.** DUNE is a proposed opt-in, low-profile mathematical research family attached to the CHUÍ cosmological simulator. **SHAI-HULUD (The Maker)** is the most ambitious **numerical method**, not an administrator or decorative Easter egg. **SPICE** is the shared structure-preserving numerical infrastructure, independently useful to normal CHUÍ; its name deliberately also evokes the electrical-engineering circuit simulator. **LITTLE MAKER** performs local geometric adaptation; **IX** designs advanced field and computational-geometry machinery. Other names have distinct mathematical purposes.

**New critical-path decision.** Fable's second research package demonstrated a **2D periodic self-consistent Vlasov–Poisson proof-of-concept with phase-sheet quadrature and KDK**, and an agent-derived **conditional conforming 2D Lagrangian atlas construction**. However, the exact atlas costs roughly 50–300 times as much as cheap high-order spline reconstruction in its tested prototype; action-aware carriers did **not** improve the self-gravitating evolution, and Monge–Ampère/OT *r*-adaptation underperformed fixed-mesh or conventional strategies in the tested regime. Therefore:

1. **Default collisionless research track:** high-order (especially quintic) spline phase-sheet carrier + mass quadrature + cheap nodal action tracking + early **local block-structured $h$-refinement**. Compare honestly with N-body at equal wall time, memory and observable error.
2. **Structure research track:** generating functions/families, symplectic atlases, discrete exterior calculus, Liouville/cohomology periods, action-aware reconstruction, and formal remapping contracts. Use the expensive exact atlas **selectively or for verification**, not as the default hot loop.
3. **IX-GRAVITAS:** proposed variational/compatible gravitational field coupling and high-order sheet-to-grid quadrature, prompted by the observed conflict between action-circulation preservation and discrete self-force/momentum in the tested PM force laws.
4. **IX-FORGE:** preserve Laguerre/OT as optional **gas moving-mesh** and geometric-research work. **Do not require OT for collisionless gravity.** The negative tests do not disprove every application of OT.
5. **Broader DUNE vision retained:** Hamiltonian/Poisson mechanics; GENERIC/metriplectic irreversible physics through WATER OF LIFE; SPICE numerical contracts; eventually hybrid sheet–particle transitions, gas coupling and possibly a deeply unified geometric evolution formulation. These remain **research hypotheses**, not tested production features.

**Most urgent next experiment:** 2D **local, block-structured $h$-refinement of a quintic sheet** in a self-gravitating Vlasov–Poisson test, with refined PM gravity and matching N-body baselines at **equal wall time and equal memory**. Improve the refinement trigger; a trigger firing at first shell crossing was already too late in the recorded tests. Only after passing 2D gates pursue cosmological EdS evolution, self-consistent 3D/6D sheet geometry, and CHUÍ integration.

**What must not be claimed:** no demonstrated 3D expanding cosmological SHAI-HULUD run; no general proof that adapting DOFs preserves a finite-dimensional symplectic structure; no conclusive numerical-performance victory over N-body; no formal Lean-verified theorem; no verified novelty relative to ColDICE, Hahn–Angulo, geometric-optics generating-family methods or variational PIC; no production CHUÍ implementation.

---

# 0. Revision history, decisions, and source hierarchy

## 0.1 Version and scope

| Version | Status | Main scientific interpretation |
|:--|:--|:--|
| v0.x — conception | Historical | DUNE lore-inspired modules; grand integration of sheets, OT, Hamiltonian and GENERIC ideas |
| v1.0 — 16 Nov 2026 | Superseded **as roadmap** | Fable's 31-page first manuscript and DeepSeek audit; action-aware OT/remap as exploratory emphasis; no self-gravity yet |
| **v1.1 — this dossier** | **Current working position** | New 2D self-gravitating experiments, conditional atlas theorem, negative OT/action-atlas cost results; high-order $h$-adaptive sheets and variational gravity take priority |

## 0.2 Explicit decisions made after the new results

**D-01 (retained):** The Maker is a scientific numerical method, never just a controller (MENTAT owns decision policies).

**D-02 (changed):** Retire **label-space Monge–Ampère OT redistribution from the collisionless gravity critical path**. Archive the formulae and failed arms; never call the entire OT discipline disproven. A future proposal must earn re-entry by matched accuracy/compute improvements.

**D-03 (changed):** A high-order spline carrier is the **default engineering baseline**. The action-aware exact atlas becomes a **specialized geometric-structure laboratory** until a much cheaper construction or unique necessary property is demonstrated.

**D-04 (new):** Local $h$-refinement is the most immediate next solver feature. Refinement must anticipate under-resolution (rather than wait for detected caustics); investigate $hp$ choices and force-error-aware refinement.

**D-05 (new):** Split IX's mathematical programme into **IX-GRAVITAS** (variational/compatible gravitational field and mass deposition) and **IX-FORGE** (Laguerre, OT and ALE geometry, primarily gas-side research). These are planned divisions, not existing implementations.

**D-06 (retained):** SPICE, WATER OF LIFE/GENERIC, little maker, the Navigator, Bene Gesserit, Golden Path, Gom Jabbar and other Dune concepts remain in the architecture, but are staged by evidence and dependencies.

**D-07 (new):** Preserve negative results, timing environment, chart failures and fallback fractions; don't optimize an aesthetically pleasing invariant at the expense of observable accuracy.

**D-08 (retained):** The experimental family must not silently modify CHUÍ's standard TreePM/AMR/chemistry path; every enabled method must be recorded in snapshot and restart metadata.

## 0.3 Evidence grading

- **ESTABLISHED:** classical mathematical results under explicit assumptions, independently checkable from derivation/literature.
- **AUTHOR-DERIVED, CONDITIONAL:** theorem/proposition argued in the supplied agent manuscript, with stated H1–H3/etc.; the dossier **does not** confer independent formal peer review.
- **REPORTED TEST:** actual test data/logs in an archive; a passing unit test is not a theorem.
- **REPRODUCED IN THIS UPDATE:** we executed `pytest -q tests` against the new Fable archive in this environment: **30 tests passed**. This is a subset of the full research experiment suite, not a repeat of every expensive study.
- **HYPOTHESIS / DESIGN:** a plausible future algorithm not mathematically or experimentally established.
- **OPEN / NEGATIVE:** stated mathematical obstruction, reproducible failure or unresolved direction.

## 0.4 Immutable inputs and provenance principle

The exact unmodified ZIPs (checksums in §13) are the final authority for what an agent actually wrote or tested. Read `research/method_decision.md` and `research/atlas_derivation.md` in the new Fable archive before citing its 'breakthrough' claims. The old Fable and DeepSeek archives remain necessary for tracing the evolution of the hypotheses. The optional chat archive documents discussions and goals, not mathematical proof.

---

# 1. Research charter and scientific objective

The project originated as an intentionally understated Dune-themed Easter egg with serious mathematics under the hood. Its motto remains: **the numerical representation may adapt to the physics, but the adaptation must have an explicit physical/error contract**.

The eventual simulated universe is a periodic comoving cosmological cube containing collisionless matter and, later, gas and dissipative physics. Cold dark matter can be modeled by a Lagrangian $d$-sheet in $2d$-dimensional phase space, then evolved with Hamiltonian dynamics. A phase sheet is a **representation**, not a competing physical evolution law. Particle release may later become necessary in deeply mixed halos, but that transition is information-losing and needs a separately validated method.

The **near-term SHAI-HULUD Engine** targets accurate, cost-effective Hamiltonian phase-sheet evolution with adaptive high-order reconstruction, conservative mass quadrature, early refinement, and consistent gravity. The **SHAI-HULUD Laboratory** preserves deeper geometric designs (exact Lagrangian atlases, generating families, multisymplectic/variational formulations, compatible regridding) with explicit scientific claims and counterexamples. This separation keeps the numerical work practical without abandoning ambitious research.

Long term, investigate mathematically compatible reversible Hamiltonian, irreversible GENERIC, field and geometric evolution. **Do not** imply that simply placing these words in one framework proves an integrator is symplectic or thermodynamically consistent.

---

# 2. Physical model and present numerical baseline

## 2.1 Cold collisionless continuum

Let the label domain be a periodic torus $\mathcal Q=\mathbb T^d$ with initial positive mass measure $\mu_0$. The phase-space map is

$$
F_t:\mathcal Q\to T^*\mathcal X,\qquad F_t(q)=(x(q,t),p(q,t)).
$$

Its fine-grained phase-space mass measure and physical-space density are

$$
\mu_t=(F_t)_\#\mu_0,\qquad
\rho_t=(\pi_x\circ F_t)_\#\mu_0.
$$

For smooth labels with density $\rho_0(q)$,

$$
\rho(x,t)=\int_{\mathcal Q}\rho_0(q)\,\delta_D\!\big(x-x(q,t)\big)\,d^dq.
$$

A caustic is associated with singularity of the configuration projection ($\det D_qx=0$), **not** necessarily singularity of the full phase-space embedding $F$. The phase sheet remains a valid continuum object after shell crossing, but finite-dimensional reconstruction becomes expensive as it folds.

## 2.2 Current proof-of-concept: 2D Vlasov–Poisson

The new Fable package provides a **2D periodic, nonexpanding** self-consistent Vlasov–Poisson test with PM/FFT gravity, particle or phase-sheet mass deposition, KDK evolution, static/reference or mid-run refinement, and matched reference controls. It is **not** a 3D cosmological or TreePM implementation. At $t=3$, its reference reports $0.3864$ negative-$\det D_qx$ label fraction (the report also calls this approximately 39% multi-stream), and maximum density about 54 in its normalization; the 512² and 1024² control trajectory RMS differs by about $4.16\times10^{-9}$.

The current primary engine proposal is:

1. Initialize smooth cold sheet with weights and a fixed Lagrangian label topology.
2. Reconstruct $x(q),p(q)$ using high-order splines, keeping a cheap nodal action $\Sigma$ for diagnostics.
3. Deposit phase-sheet mass via sub-element quadrature on the **shared** PM mesh; never count an element both as a sheet and as released particles.
4. Solve a consistent PM field, gather forces and advance phase-space nodes with KDK.
5. Estimate **state-only** local error (candidate: fourth differences in $x,p$ scaled against PM cell size), supplement with force/deposition estimates and predictor indicators.
6. Refine selected blocks in label space **before** the onset of under-resolution; reconstruct new nodes from the old high-order carrier. Avoid repeated node redistribution by default.
7. Audit action periods, two-form defects (where $d\ge2$), mass, momentum, energy balance, force errors, PM resolution, runtime and memory.

This sequence is a design/prototype path, not a derived globally structure-preserving discrete algorithm.

## 2.3 What we learned about accuracy versus storage and CPU

With comparable **deposition sample counts**, high-order sheets can sometimes use **four to sixteen times fewer evolving nodes** than particles without sacrificing accuracy in the tested period. The new report documents 32² nodes with cubic quadrature at 128² deposited points matching 128² particles before shell crossing, while bilinear quadrature performed badly. After shell crossing, 64² nodes were needed to recover the tested accuracy. This is a potential **node-storage/memory advantage**, **not an established runtime speedup**: deposition/Poisson/gather work remains material.

At fixed PM grid and $t=3$, one reported table gives the following **position RMS errors against the high-resolution reference** (all values are in the prototype's nondimensional units):

| Representation (128² deposition samples) | Evolving nodes | Position RMS error |
|:--|--:|--:|
| N-body | 16,384 | $3.68\times10^{-6}$ |
| Cubic sheet | 1,024 | $1.65\times10^{-5}$ |
| Cubic sheet | 4,096 | $2.53\times10^{-6}$ |
| Action-aware `ac3g` | 1,024 | $5.17\times10^{-5}$ |
| Conforming exact atlas `csa3g` | 1,024 | $6.01\times10^{-5}$ |

**Interpretation:** increasing the resolution of a conventional sheet recovered accuracy; action-aware reconstruction did not help self-gravity at comparable coarse resolution. It is unfair to compare these errors without noting node counts, deposition samples, grid force error, and timing.

![Fable's 2D Vlasov–Poisson benchmark figure; numerical evidence from the supplied archive.](dossier_assets/fig_vp.png){width=95%}

## 2.4 The force-discretization obstruction

The reported PM study compares an **exact gradient of one interpolated scalar potential** with a **standard momentum-conserving PM force**. In this implementation:

| Force formulation | Action-period drift | Momentum/self-force | Caveat |
|:--|:--|:--|:--|
| Common-potential gradient | $\sim2\times10^{-12}$ | Measured self-force; momentum drift $\sim10^{-5}$ | More accurate action ledger but grid symmetry is not sufficient |
| Momentum-conserving PM | $\sim1.4\times10^{-5}$ | Zero self-force, momentum error $\sim10^{-16}$ | Larger nonconvergent action/energy residual in the reported test |

These are results for the tested assignment/force implementations, **not** a universal impossibility theorem. They motivate IX-GRAVITAS: can deposition, potential energy and force be derived from one compatible semidiscrete variational construction while retaining useful discrete symmetries?

## 2.5 Cosmological extension is separate

In expanding cosmological coordinates, under an explicitly defined convention one may use comoving $x$ and canonical per-unit-mass momentum $p=a^2\dot x$ with a time-dependent Hamiltonian $H=|p|^2/(2a^2)+\phi(x,t)$. The Poisson normalization, kick/drift factors, potential and Layzer–Irvine balance must be derived and checked in the actual CHUÍ convention. **The new Fable breakthrough did not execute an expanding-background EdS cosmological run.** The EdS work in the older archive used a prescribed potential and is not a self-consistent cosmological validation.

---

# 3. Geometric and dynamical mathematics

## 3.1 Hamiltonian sheet and action

In canonical coordinates, with a consistent convention for the sign of $\omega$,

$$
\theta=p\cdot dx,\qquad \omega=d\theta=\sum_i dp_i\wedge dx_i.
$$

A $d$-dimensional Lagrangian immersion into $2d$-phase space satisfies $F^*\omega=0$. Its pulled-back canonical one-form is closed; locally $F^*\theta=d\Sigma$. On a non-simply-connected label domain, $\Sigma$ may have periods:

$$
F^*\theta=dS+\sum_{i=1}^dc_i\,dq_i,
\qquad
c_i=\oint_{\gamma_i}F^*\theta,
$$

where $\gamma_i$ are the fundamental cycles of the label torus (normalization of the basis of one-forms is part of the convention). A purely local action interpolation does not automatically reproduce these periods. An exact smooth Hamiltonian flow preserves the relevant symplectic/Poincaré structures; a discrete reconstruction or node-number change need not.

For a time-dependent relabeling $q=T_t(\xi)$, the physical distribution is unchanged at continuum level if the measure is transformed as $\widetilde\mu_0=T_t^*\mu_0$; this is **not** a proof that a finite-element remap preserves action or physics. It was central to the original OT proposal but remains true independent of OT.

## 3.2 Fable's conforming symplectic-atlas result — scope and hypotheses

The later Fable report defines an action mismatch one-form for an interpolated carrier $z_h=(x_h,p_h)$ and an action interpolant $W_h$:

$$
\beta=z_h^*\theta,\qquad \kappa=dW_h-\beta.
$$

In a suitable local symplectic frame $(Y,P)=\mathsf M(x,p)$ with invertible label Jacobian $D_\xi Y_h$, its correction is

$$
Y=Y_h,\qquad
P=P_h+(D_\xi Y_h)^{-T}\kappa.
$$

The formal calculation in `research/atlas_derivation.md` shows $F^*\theta=d\Sigma_{\rm car}$ and $F^*\omega=0$ **within that valid chart**, subject to regularity. The new **Theorem 5** attempts global **$C^0$ conforming** gluing for a 2D sheet: correct nodal tangent two-form, add edge-action bubbles to close edge integrals, build a Coons action potential, then apply independent per-cell symplectic-frame corrections. Its key assumptions are:

- **H1:** nondegenerate nodal tangent condition $g^2>4c^2$.
- **H2:** nonzero coefficient in each edge-action bubble correction.
- **H3:** a valid local frame exists with $\det D_\xi Y_h\ne0$ on the **closed** cell.

Under these assumptions the author claims an interpolatory, continuous, piecewise smooth, exactly Lagrangian carrier within each open cell, with action periods matched to the supplied values and arbitrary valid neighboring frames. This is **an agent-authored conditional mathematical proof claim**, supported by symbolic/numerical tests, not an independently referee-verified result. It is **not** globally $C^1$, and **fallback cells** can be continuous without pointwise Lagrangian structure. The 3D/6D conforming face/edge closure is **open**.

There are three distinct claims: (**S1**) the geometric carrier is intrinsically Lagrangian; (**S2**) it approximates the physically correct sheet accurately; (**S3**) the full nodal map of the time integrator is symplectic. **S1 does not imply S2 or S3.** This distinction explains why the exact atlas can 'win' on two-form diagnostics but lose on physical errors and CPU.

![Representative atlas diagnostic from Fable's prototype.](dossier_assets/fig_atlas_maps.png){width=95%}

## 3.3 DeepSeek's restricted symplectic no-go and information loss

For a linear averaging/coarsening map $x'=Dx,p'=Dp$ with positive diagonal nodal masses $M,M'$ and a row-stochastic nonnegative $D$, preservation of the corresponding mass-weighted nodal two-form requires

$$
D^\top M'D=M.
$$

The positivity and off-diagonal zeros imply that target rows cannot mix two source nodes: only copying/permutation with suitable mass splits survive under the specific assumptions. This is **not a theorem forbidding nonlinear interpolatory action-corrected reconstruction**, nor does it prove that a state-dependent nonlinear map is globally symplectic. A separate weighted-variance identity shows where bulk kinetic energy goes under averaging (unresolved velocity dispersion).

The one-dimensional pullback of a two-form is identically zero—**1D two-form tests are vacuous**. The first nontrivial test is a 2D label sheet in 4D phase space. The two-form defect is also **not** a caustic detector: $\det D_qx$ and $F_h^*\omega$ are different diagnostics.

## 3.4 Structural and physical error must be measured separately

Minimum diagnostics for a state or transition:

$$
\begin{aligned}
\eta_{\rm state}&=\|F_h-F_{\rm reference}\|,\\
\eta_{\rm geom}&=\|F_h^*\omega\|,\\
\eta_{\rm period}&=\max_i\left|\oint_{\gamma_i}F_h^*\theta-c_i\right|,\\
\eta_{\rm grav}&=\|\rho_h-\rho_{\rm ref}\|+\lambda_F\|g_h-g_{\rm ref}\|,\\
\eta_{\rm transfer}&=\|\mathcal P(F_h)-F_{\rm ref,transferred}\|.
\end{aligned}
$$

These are **schematic metrics**; norms, reference grids, dimensionless weighting and appropriate weak norms for caustics must be specified. A numerically zero two-form defect cannot substitute for small force or density error. A local refinement trigger should be evaluated on the evolving state alone, not a reference/oracle unavailable in production.

---

# 4. DUNE module family — updated responsibilities

All of the following are *planned research modules* unless the source packages explicitly provide a standalone Python experiment; none is thereby integrated into production CHUÍ.

| Codename | Current mathematical responsibility | Evidence/stage |
|:--|:--|:--|
| **SHAI-HULUD** — The Maker | Adaptive Hamiltonian evolution of high-order phase-space manifolds; experimental exact-atlas and compatible-reconstruction track; distant reversible/irreversible geometric unification | 2D Python research prototype; 3D full solver open |
| **SPICE** — Structure-Preserving Interchange and Conservative Evolution | Reusable Poisson/GENERIC operators, action/period ledger, transfer contracts, consistent discrete gradients and invariant diagnostics | Architecture proposal; selected Python diagnostics exist |
| **IX-GRAVITAS** | Variational gravitational energy, compatible field operators, action- and momentum-aware mass deposition/force coupling, high-order sheet quadrature | New research proposal, motivated by reported PM tradeoff |
| **IX-FORGE** | Laguerre/OT geometry, moving-mesh ALE optimization and experimental gas-oriented geometric solvers | OT label remap failed tested gravity benchmarks; gas value untested |
| **LITTLE MAKER** | Local block-structured $h$-refinement, eventual anisotropic $hp$-adaptation, shape/curvature/force indicators and refinement provenance | Uniform $h$-refine prototype; local blocks not yet implemented |
| **ARRAKIS** | Periodic domains, topology, coordinate lifts, chart/geometric queries, MPI geometry adapters | Planned shared infrastructure |
| **KWISATZ HADERACH** | Conservative/refinement and, later, sheet-to-particle transfer; explicitly classify lost fine-grained information | Proposed numerical contracts; no validated release solver |
| **MENTAT** | Cost/error/memory-bounded decisions, hysteresis, policy optimization (administration **only here**) | Proposed, not Maker's core invention |
| **GUILD NAVIGATOR** | Predict **pre**-caustic/force-error/refinement requirements; calibrate short-horizon physics-aware triggers | Proposed; high-priority future improvement |
| **GOM JABBAR** | Adversarial stress tests, theorem falsification, degeneracy/fallback audits and reproducibility | Existing test-suite seed, 30 new regression tests |
| **BENE GESSERIT** | Adjoint/automatic differentiation and sensitivity of physical observables and numerical choices | Long term |
| **GOLDEN PATH** | Alternative cosmological histories and uncertainty quantification | Long term |
| **WATER OF LIFE** | GENERIC/metriplectic dissipative thermodynamic closure: irreversible gas, chemistry, radiation, diffusion | Distant, independent physics research |

**Complexity hierarchy ≠ source dependency hierarchy:** SHAI-HULUD remains the crown-jewel scientific question, SPICE is the reusable infrastructure immediately beneath it in ambition, and IX/LITTLE MAKER support particular mathematical branches. Real libraries should depend *upward* only on stable numerical primitives; avoid cyclic ownership.

## 4.1 IX's revised scientific identity

IX must provide **real mathematics**, not become another manager. The proposed two-research-division model follows the Ixians' association with sophisticated machinery:

**IX-GRAVITAS (new gravity-side center).** Investigate a consistent semidiscrete gravitational energy $U_h$ assembled from sheet quadrature, a field solver and a self-interaction convention, and derive generalized nodal forces through

$$
H_h(X,P)=K_h(P)+U_h(X),\qquad F_a=-\frac{\partial U_h}{\partial X_a},
$$

with the proper state variables/weights. If a chosen fixed PM mesh breaks continuous translation symmetry, a discrete variational derivation **does not automatically** restore exact momentum conservation or eliminate self-force. Study whether compatible deposition/gather, Fourier-Galerkin fields, momentum constraints, or variational PIC analogues can improve the tradeoff at acceptable wall cost.

**IX-FORGE (optional gas/geometry laboratory).** Continue semi-discrete OT/Laguerre cells, anisotropic geometry and high-order conservative moving meshes where their physical benefits can be measured. Failure of repeated label-space OT remapping for collisionless sheets **does not** invalidate mass-constrained Laguerre hydrodynamics; it simply moves that research off the immediate gravity critical path. No moving-mesh gas benchmark was included in the supplied Fable breakthrough.

## 4.2 SPICE and WATER OF LIFE remain distinct

SPICE should eventually expose contracts such as `(domain, measure, conservative quantities, positivity, geometric structure, residuals, adjoint availability, failure criteria)`, with SoA-friendly data layouts. It must remain useful when SHAI-HULUD is disabled. WATER OF LIFE supplies physical GENERIC models for dissipative subsystems, not a blanket metriplectic term applied to ideal collisionless dark matter.

For closed finite-dimensional GENERIC systems,

$$
\dot z=L(z)\nabla E(z)+M(z)\nabla S(z),\quad
L^\top=-L,\quad M^\top=M\succeq0,
$$

with required Poisson/Jacobi structure and degeneracies $L\nabla S=0$, $M\nabla E=0$. For open radiation, reacting gas, cosmic expansion or external work, correct source/flux terms and energy/entropy accounting must be introduced. **No coupled GENERIC gas+sheet cosmological solver exists in the source archives.**

## 4.3 Planned source layout (nonbinding)

```text
experimental/dune/
  spice/                     # operator contracts, invariants, GENERIC primitives
  shai_hulud/engine/         # high-order sheet evolution and mass carrier
  shai_hulud/laboratory/     # exact atlas, generating families, geometry tests
  ix/gravitas/               # variational deposition / potential / forces
  ix/forge/                  # Laguerre/OT gas-side and general geometry
  little_maker/              # local h/hp refinement + error indicators
  arrakis/                   # topology and periodic geometry
  kwisatz_haderach/          # transfers and information-loss ledger
  water_of_life/             # thermodynamic closure and dissipation
  mentat/                    # optional resource-aware decisions
  guild_navigator/           # forward error/refinement predictors
  bene_gesserit/             # discrete adjoints / sensitivities
  golden_path/               # ensembles / uncertainty
  gom_jabbar/                # adversarial mathematical tests
```

This is **not** a claim about the current CHUÍ directory tree.

---

# 5. Fable breakthrough mission — measured evidence and negative results

The principal new source is `shai-hulud-fable-breakthrough-results(1).zip`, containing `work/fable_breakthrough/`. Begin with `research/method_decision.md` (the author's verdict), `research/atlas_derivation.md` (conditional theorems), `results/SUMMARY.md` (generated from JSON), and `RELEASE_NOTES.md` (scope and incidents). The package holds Python `src/shsheet/`, 30 regression tests, experiments A/B/C/D and saved data. It did **not** modify CHUÍ production sources.

## 5.1 What was actually demonstrated

**A — Atlas reconstruction:** under H1–H3, the author derives a $C^0$ conforming 2D Lagrangian carrier with local symplectic frames even across configuration-space folds. Reported near-machine-precision edge continuity, action-loop integrals and internal two-form checks on valid cells. Fallbacks are sometimes necessary in under-resolved cases: the entire computational state is then **not** everywhere pointwise exactly Lagrangian.

**B — Repeated remapping:** the position-preserving atlas showed substantially reduced **normal reconstruction error** in many prescribed-flow repeated-remap cases at equal degree/node count. But it used far greater setup/storage, and cheaper quintic interpolation often gave better full position or momentum accuracy per CPU.

**C — 2D self-gravity:** a running periodic Vlasov–Poisson sheet solver, sheet quadrature/PM forces and refinement experiments. Simple cubic and quintic carriers outperformed the action-corrected carriers in the selected self-gravitating benchmarks; PM force accuracy often dominated.

**D — 3D chart exploration:** locally good frame conditioning and small calculated two-form defects in valid cells, but without conforming face/edge closure the carrier had seam jumps and order loss. This is **not** a working 3D phase-sheet solver.

## 5.2 Timings and representation costs

| Carrier, 64² nodes | One reconstruction/remap (clean reported timing) | Role now |
|:--|--:|:--|
| Cubic spline | 3.0 ms | Fast baseline |
| Quintic spline | 16.6–17 ms | Main high-accuracy baseline |
| Exact cubic atlas `csa3g` | 888.7–889 ms | Structure laboratory |
| Exact quintic atlas `csa5g` | 1,277–1,278 ms | Structure laboratory |

The Python prototype is not optimized, so ratios do not directly predict C++ HPC speed; they do establish that **no measured present performance justification exists** for making the exact atlas default. Atlas storage is reported around **104–128 floats per node versus roughly five for the base carrier** in these tests.

![Numerical reconstruction accuracy and structural residuals reported by Fable.](dossier_assets/fig_accuracy.png){width=90%}

## 5.3 Adaptive experiments: OT loses in this configuration

In a recorded fixed-$n=64$ cubic-sheet test at $t=2$ (position RMS / density relative error):

| Adaptation (matched test family) | Position | Density |
|:--|--:|--:|
| Fixed label mesh | $1.03\times10^{-6}$ | $9.2\times10^{-6}$ |
| Separable $d4$ map, 2 remaps | $6.4\times10^{-7}$ | $1.2\times10^{-5}$ |
| Separable $d4$ map, 6 remaps | $2.9\times10^{-6}$ | $3.8\times10^{-5}$ |
| OT-$d4$ map, 2 remaps | $1.6\times10^{-6}$ | $5.3\times10^{-5}$ |
| Fixed uniform mesh with $2n$ per dimension | $5.9\times10^{-8}$ | $5.4\times10^{-7}$ |

The agent's broader report counts **80 method-native $r$-adaptation arms**: 52 improved momentum, only 27 improved position, and 9 improved the chosen density observable; **none** of those 9 used the conventional cubic/quintic carriers. This is strong negative evidence against making OT **routine sheet-node redistribution** the default, not a proof that all possible optimal transport approaches are unhelpful.

The action-edge-defect monitor was a poor refinement driver on the PM grid: according to the report it saturated at grid-scale force roughness, and a conventional fourth-difference state monitor was better. Its use as a **diagnostic** remains valuable.

## 5.4 $h$-refinement: encouraging but still global

In the tested run, increasing the sheet from **32² to 64² nodes at $t=1.5$** using high-order carrier reconstruction produced a final $t=3$ position error of about $2.5\times10^{-6}$, comparable to evolving 64² from the beginning. Refining at $t=2$ was about three times worse—**the trigger came too late**. Linear/bilinear transfer had produced much larger errors in related tests, consistent with the DeepSeek warning about remapping from insufficiently accurate carriers.

This supports *high-order refinement from the carrier*, but **does not yet demonstrate local block-structured, nonuniform $h$-refinement**. That is the next experiment, not a completed capability.

## 5.5 Accuracy under PM force resolution changes

The report notes that varying the PM grid from 64² to 256² changed some $t=3$ node positions by roughly $5\times10^{-3}$, larger than many sheet-reconstruction differences at a fixed grid. Thus, comparing two sheet interpolants without convergence of the gravitational force can overstate physical significance. Use refined PM grids and compare against a reference calculated on the **same field discretization** before claiming a geometric benefit.

## 5.6 Known atlas and 3D limits

- The exact atlas theorem's validity is **conditional** on nondegenerate tangent data, workable edge correction and a valid frame per cell (H1–H3). Chart fallback fractions must be reported.
- In some strongly folded cases the exact carrier has **worse** position or normal accuracy than a cheaper skeleton-exact or spline carrier.
- Continuity is $C^0$; tangent planes may jump across cell edges. General globally $C^1$ gluing remains open.
- The 3D/6D trial has only **local** frame corrections; conforming edge → face → cell closure was not implemented.
- The tested PM sheet quadrature did not use a fully consistent 'node-Hamiltonian' adjoint force, and discrete total energy is therefore not guaranteed by the tests.
- No EdS cosmological run, no sheet-to-particle release, no C++/MPI/CHUÍ integration, no formal Lean verification, and no comprehensive scientific novelty review were attempted in the breakthrough mission.

## 5.7 Fable's own scientific decision

The source report states **CONDITIONAL GO** for a high-order spline-sheet plus $h$-refinement solver; **NO-GO as default** for action-aware reconstruction; and **NO-GO in the tested configuration** for OT $r$-adaptation. Respect that negative evidence. The excellent structural accuracy of the atlas is a **separate success metric** from physical accuracy and cost.

---

# 6. DeepSeek mathematical audit — retained evidence

The archive `shai-hulud-lab(2).zip` contains a mission audit, formal notes and seven numerical experiments. Its original draft inputs were not all verified; prefer the corrected final `reports/mission_01.md`, `research/proof_ledger.md`, `research/discrete_method.md` and `experiments/results/`.

**Key algebraic result:** for a nonnegative row-stochastic averaging matrix $D$ with positive source/target mass matrices, exact preservation of the mass-weighted nodal symplectic bilinear form requires $D^\top M'D=M$ and excludes true mixing under the stated conditions. This is **restricted to that map class**. It should never be misquoted as disproving nonlinear action-aware carriers or continuous relabeling.

**Kinetic-energy identity:** averaged bulk kinetic energy differs from incoming kinetic energy by a nonnegative within-cell velocity variance under the usual positive weights; such unresolved dispersion is real missing information, not mysteriously conserved energy.

**2D diagnostic:** the pullback two-form defect is nontrivial in two label dimensions, unlike 1D. In a particular potential-flow family, the first-order geometric defect can remain independent of the amount of spatial folding while $\det D_qx$ changes sign; **use separate caustic and structure monitors**.

**Remapping stress test:** a graded 2D mesh with freshly evaluated exact-node data improved its global RMS approximation over uniform data, but when graded nodes were populated from the *old approximate carrier*, the new error could be worse. Fable's more recent cubic/quintic experiments show this negative result is strongly carrier/order and remap-count dependent; do not elevate the one low-order case to a universal theorem.

**GENERIC oscillator:** finite-dimensional closed-system integrator checks support correct degeneracy/entropy accounting for a damped oscillator with a heat reservoir. That is valuable for future WATER OF LIFE, **not** a validation of astrophysical chemistry, radiation or gas hydrodynamics.

**Reconciliation:** the DeepSeek and Fable methods are fundamentally different operations (coarse averaging vs nonlinear action-aware reconstruction). Their results constrain rather than invalidate each other.

---

# 7. New mathematics worth developing after retiring OT from gravity

This section records **new research proposals from the subsequent architecture discussion**, not methods demonstrated in the supplied Fable/DeepSeek source archives. Their main purpose is to replace *routine OT sample relocation* with more relevant geometrical, variational and field-theoretic mathematics.

## 7.1 Generating families and symplectic atlases — strongest geometric candidate

A simple configuration-space generating function $p=\nabla_x S(x)$ may fail as a **single-valued chart** at spatial caustics. An auxiliary-parameter **generating family** may instead describe multiple branches via

$$
\partial_\alpha S(x,\alpha)=0,\qquad p=\partial_x S(x,\alpha).
$$

Multiple critical points in $\alpha$ can encode multiple streams at the same spatial $x$. An adaptive atlas could employ ordinary high-order carrier elements almost everywhere and more expensive generating-family/symplectic-chart machinery only near problematic folds. This concept draws on known Lagrangian singularity theory; it is **not** an originality claim. Global generating-family existence, chart transitions, singular sets, periods, inter-cell regularity, and computational overhead must be established.

**First experiment:** one 2D fold-caustic sheet with known analytic embedding and multiple charts; reconstruct through the fold and quantify chart continuity, normal/tangential error, two-form residual, force contribution, and cost against a quintic spline. Only activate exact charts where the cheap representation fails an agreed physical threshold.

## 7.2 Differential forms, topology, and global action periods

On $\mathbb T^d$, $F^*\omega=0$ implies the one-form $\alpha=F^*\theta$ is closed, but does **not** imply it is globally exact. On the torus, its cohomology class is detected by fundamental periods. This suggests a **global action-period and topology ledger** independent of local interpolation:

$$
[F^*\theta]\in H^1(\mathbb T^d;\mathbb R),\qquad
c_i=\oint_{\gamma_i}F^*\theta.
$$

A discrete exterior calculus (DEC) or compatible cochain representation might track edge integrals, face closure residuals, cycle periods and topology during block refinement. **Caveat:** reporting a cochain with small closure residual is not proof that the full physical state evolution is symplectic; it is a numerically useful separate contract.

**First experiment:** refine/coarsen a periodic 2D sheet and verify cycle periods, discrete Stokes identities, numerical cohomology and a separate physical-density error across arbitrary block interfaces.

## 7.3 Variational $hp$-adaptation — immediate implementation replacement

Rather than continuously changing **where** all sampling nodes reside ($r$-adaptation), adapt **how the geometry is approximated**: split elements ($h$), increase local polynomial order ($p$), or combine both ($hp$). A possible error-budget objective is

$$
\min_{\{h_K,p_K\}}
\sum_K\big[w_g\eta_{K,\mathrm{geom}}^2+w_F\eta_{K,\mathrm{force}}^2+w_\rho\eta_{K,\rho}^2\big]
+\lambda_T C_{\rm CPU}+\lambda_M C_{\rm RAM},
$$

subject to **hard** admissibility, mass, memory, conformity and smoothness/limiter constraints. This is a *design model*, not a derived unique variational principle. Normalization and estimates must be calibrated to physical observables; a purely curvature-based monitor can waste refinement on geometrically complicated regions whose potential is already accurate.

Known adaptive phase-space methods (notably ColDICE and Hahn–Angulo) have significant prior art. Potential contribution would lie in **provably better/error-controlled coupling of $hp$ choices to gravitating observables**, or in a new low-cost invariant-compatible local transfer. Refine early enough to prevent projection-error growth rather than responding only to the completed caustic.

**First experiment:** local block-structured quintic refinement with coarse/fine transfer and shared PM deposition; match wall time, peak resident memory, force error and observable accuracy against N-body.

## 7.4 Geometric particle–field Hamiltonians — IX-GRAVITAS

Construct field variables $\phi_h$ and mass/deposition operators from a consistent semidiscrete action or energy; derive forces via the variation of the **same** discrete energy $U_h$:

$$
H_h(X,P)=K_h(P)+U_h(X),\qquad \dot X=\partial_P H_h,\qquad \dot P=-\partial_X H_h.
$$

For sheet quadrature, $X$ can include geometric degrees of freedom whose motion changes quadrature locations. The correct force is an adjoint derivative of the discretized gravitational energy through those dependencies, not necessarily ordinary force interpolation at nodes. Include periodic zero-mode handling, self-interaction conventions and grid assignment.

**Noether caveat:** a variational discretization has exact discrete momentum only if it has the relevant symmetry. A fixed PM mesh may break continuous translation symmetry, so action preservation, zero self-force and momentum conservation should be evaluated **jointly** and the failure traced to symmetry/field discretization rather than papered over by claims of automatic consistency.

**First experiment:** isolate a 1D/2D periodic toy sheet–field Hamiltonian and compare a common-potential-gradient force, a standard momentum-conserving PM force, and an energy-derived adjoint force on the same state and grid. Audit self-force, momentum, action period, secular energy and total compute cost.

## 7.5 Multisymplectic / space–time variational discretizations — high risk

For suitable field theories, covariant multisymplectic frameworks constrain the interaction between discretization in space and time. A Lagrangian phase-sheet is parameterized by **material labels** and interacts through nonlocal gravity, so naively importing a spacetime-PDE multisymplectic integrator is not justified. A carefully specified discrete Lagrangian could, however, yield new coupling/long-time diagnostics. Keep this as a **separate mathematical laboratory**, not a default replacement for proven KDK.

## 7.6 Hierarchical phase-space approximation and compression

Investigate wavelets or hierarchical local bases for a sheet embedding,

$$
F(q,t)\simeq F_{\rm coarse}(q,t)+\sum_{\ell,k}c_{\ell k}(t)\psi_{\ell k}(q),
$$

where coefficient pruning respects mass and controlled geometric/error contracts. Independent truncation of position and momentum generally violates $F^*\omega=0$, so consider a generating function, constrained projection or explicit defect budget. Strongly phase-mixed regions can have intrinsically high information content; **compression cannot magic away physical folds**.

## 7.7 How the proposed mathematics fits together

**Engine:** efficient high-order sheet + KDK + quadrature + local $h/hp$ adaptation.

**Geometric lab:** generating families and localized exact atlas; global action/cohomology and DEC; invariant-constrained transfer.

**IX-GRAVITAS:** consistent variation of the sheet–field Hamiltonian, compatible Poisson field and force operators.

**SPICE:** reusable contracts, checks and (later) GENERIC/thermodynamic operators.

**WATER OF LIFE:** separate future reversible–irreversible physical modeling. The proposed mathematics must earn its CPU/memory cost through testable improvements rather than simply increasing mathematical sophistication.

---

# 8. Formal claim / proof / obstruction ledger (updated)

| ID | Statement | Present classification | Next check |
|:--|:--|:--|:--|
| G-01 | Exact Hamiltonian evolution preserves the appropriate symplectic geometry | Established under standard regularity | Document cosmological variable conventions |
| G-02 | Continuum invertible relabeling with pulled-back mass preserves physical measure | Established identity | Verify discrete mass integration |
| G-03 | A 2D phase sheet has nontrivial two-form defect; in 1D the pullback is vacuous | Established | Apply three component tests in 3D |
| G-04 | Nonnegative linear row-stochastic coarse averaging is symplectic except trivial cases | Restricted proof claim (DeepSeek), algebraic under stated assumptions | Independent algebraic/formal review |
| G-05 | Fable's conforming 2D atlas is pointwise Lagrangian in all cells satisfying H1–H3 | **Author-derived conditional theorem**, numerically checked | Independent theorem review and pathological cases |
| G-06 | Atlas carries exact global periods and continuous edge traces | Conditional on H1–H3 and correct discrete closure | Audit nontrivial periods, fallback, orientation |
| G-07 | $C^1$ conforming 2D exact atlas with comparable efficiency | Open | Evaluate regularity obstruction / smoother construction |
| G-08 | Conforming exact 3D/6D carrier with edge/face/cell closure | Open | 3D hierarchical closure plus error/cost study |
| G-09 | Action atlas generally improves self-gravity at equal runtime | **Not supported** by tested benchmarks | Restrict claim; seek niches only |
| G-10 | Repeated OT $r$-adaptation is a competitive collisionless default | **Contradicted** in tested configurations | Deprioritize, retain as negative baseline |
| G-11 | Quintic sheet + quadrature + early high-order $h$ refinement is viable | Numerically promising, restricted 2D proof of concept | Local blocks, matched N-body, force convergence |
| G-12 | PM action preservation, zero self-force and momentum can be obtained together | **Open**, tested forces exhibit tradeoffs | IX-GRAVITAS consistent field derivation |
| G-13 | Generating-family atlas near caustics improves physically important errors per CPU | New hypothesis | Matched local-chart A/B experiment |
| G-14 | DEC/action cohomology ledger can survive local $hp$ remeshing with controlled residuals | New hypothesis | Discrete cochain and period tests |
| G-15 | GENERIC/mass-transfer gas coupling is thermodynamically consistent in cosmology | Open, distant | Isolated reversible/irreversible references first |
| G-16 | Full SHAI-HULUD beats CHUÍ TreePM/N-body in 3D cosmology | **Not demonstrated** | Do not claim before complete benchmarks |

**Cross-check that survived from the prior dossier:** the initial Fable monitor objective/exponent algebra was inconsistent as written. The newer benchmark's `d4` monitor performed better than action-edge monitors. **Do not reintroduce the old $d/(d+3)$ action-monitor formula** until the underlying functional is unambiguously defined and re-derived; a better benchmark does not retrospectively fix a defective derivation.

---

# 9. Execution roadmap and explicit gates

## Gate A — Lock the scientific baseline (immediate)

**Inputs:** preserve the 30-test archive; run and hash all experiments when resources permit; freeze numerical conventions, seeds, PM kernel, reference states and error norms; validate the 512² vs 1024² controls and convergence in PM force grid and time step. **Pass:** a reproducer can regenerate the principal tables and identify discrepancies with source hashes. Keep failed arms and chart fallback reports.

## Gate B — 2D local block-structured $h$-refinement (next decisive experiment)

Implement **nonuniform local refinement** of the high-order (quintic preferred) sheet on a 2D label mesh; manage hanging interfaces, coarse/fine mass partition, high-order interpolation and KDK node ownership. Use evolving-state estimators only—no oracle online. Candidate indicator: local fourth differences of $(x,p)$ in a label-space metric, scaled by projected gravitational cell size, with a predictive safety margin. Compare multiple trigger times including $t<1.5$, $t=1.5$ and near first crossing in the supplied test.

**Success:** demonstrate that, at $t=3$ with at least 30% folded reference labels and PM grid at least 256², the sheet gives at most N-body's position and density error at **equal wall time**, and at most half N-body's errors at **equal memory**, on two consecutive force-grid resolutions. This is Fable's own suggested falsifiable threshold, **not a guaranteed outcome**. Measure peak RSS, CPU-hours and allocation overhead. **Failure:** if not met consistently, retain the sheet as a memory/structure-specialized method, not a default replacement for N-body.

## Gate C — IX-GRAVITAS force compatibility

Derive a concrete **semidiscrete energy** incorporating sheet quadrature and a periodic field; differentiate the actual discrete energy to obtain a candidate adjoint nodal force. Compare against the two previously tested PM laws. **Pass:** consistent error convergence and acceptable self-force/momentum/action tradeoffs at a stated cost; a proven discrete conservation identity is desirable but not assumed. A negative tradeoff result is still worth publishing as a well-defined numerical limit.

## Gate D — Selective exact-geometry improvements

Build generating-family and/or local symplectic-atlas activation **only on diagnosed problem cells**, with explicit H1–H3/fallback handling and matching across neighboring simple spline cells. Audit full-state and force error, not only two-form. **Pass:** a reproducible physical advantage (or uniquely necessary invariant) with bounded overhead; otherwise keep atlas for verification alone.

## Gate E — 3D conforming geometry and expanding cosmology

Derive and test **3D label / 6D phase-space** local elements. For exact atlases, solve edge → face → cell closure and cyclic periods under nontrivial topology. Separately port the *cheap* high-order sheet with local refinement to 3D before spending on costly exact reconstruction. Add correctly defined EdS/cosmological-time KDK and Layzer–Irvine diagnostics. **Pass:** convergence and conservation/error budgets compared with standard N-body and established sheet baselines.

## Gate F — Hybrid representation and multiphysics

Introduce one-way sheet-to-particle release only after sheet errors and force accuracy are characterized. Maintain mass ledgers, sampling/moment error, no double counting and explicit information loss. Later test SPICE + WATER OF LIFE GENERIC-compatible gas, then AMR/Godunov/chemistry/radiation; source/sink accounting must reflect open systems and cosmological work.

## Gate G — Production CHUÍ, performance and extension family

Port validated kernels to C++ with SoA-friendly data, thread-safe geometry, MPI owner rules, deterministic testing, memory-governor integration, HDF5 restart lineage and unique feature metadata. Keep standard CHUÍ runtime ownership for gravity and timesteps. Only then add Navigator prediction, Mentat policies, Bene Gesserit adjoints, and Golden Path ensembles.

---

# 10. Experimental design and acceptance metrics

## 10.1 Baseline arms to compare

- N-body PM with the **same physical field solver and timestep**.
- Conventional linear/bilinear phase carrier (negative baseline).
- Cubic spline sheet and quintic spline sheet.
- Cubic/quintic with early uniform $h$-refinement (existing positive controls).
- Cubic/quintic with *new local* $h/hp$-refinement.
- Action skeleton `ac3g` and conforming atlas `csa3g/csa5g` as structure-focused optional arms.
- OT-$r$ adaptation and cheap separable maps as **archived negative controls**, only when specifically re-testing r-adaptation.

At least two PM grid resolutions, two node budgets, several trigger timings and fixed random seeds are needed. Compare **equal wall time**, **equal peak memory**, and **equal physical observable error**, not simply equal number of sheet nodes.

## 10.2 Physics metrics

Position and momentum RMS/max against a converged control; Fourier density error, power spectra where meaningful, gravitational force RMS and near-caustic error; phase-space stream/caustic locations; multistream fractions and Jacobian sign changes; mass and momentum drift; energy/Layzer–Irvine balance; action-cycle residuals; two-form defect and fallback-cell fraction; artifact-free periodic seams; reproducible restart results.

Important: a perfect geometric invariant on an inaccurate sheet is not success. A physically accurate method with small bounded geometric defect can be scientifically preferable.

## 10.3 Engineering metrics

Wall-clock elapsed time, CPU time (including parallel BLAS threads), peak resident memory, total quadrature points, total evolving nodes, PM mesh and communication volume, allocation count, variance across repetitions and cost of setup/transfer/diagnostics. GPU timings should never be compared to CPU results without a separate normalized setup. Python prototype timings are ranking evidence, not production C++ predictions.

## 10.4 Nonnegotiable falsification cases

Strongly folded caustics; underresolved H3 chart; nonzero torus action periods; periodic seam crossing; degenerate or near-degenerate tangents; PM self-force with isolated particles; large PM force roughness; repeated adaptation and trigger too late; coarse/fine interface conservation; switched force law; regridding that worsens potential energy; positive-weight averaging coarsening; high-frequency sheet geometry where compression loses important modes.

---

# 11. Implementation contracts, interfaces and tests

The following interfaces are **conceptual** and not a claim about CHUÍ's current C++ symbols.

| Contract | Inputs | Postconditions / diagnostic evidence |
|:--|:--|:--|
| `PhaseSheetCarrier` | label topology, nodal $x,p$, spline coefficients, optional action | evaluation of $F(q)$, derivatives, element mass, continuity/order, error estimates |
| `QuadratureDeposit` | sheet geometry, positive mass measure, PM assignment | global deposited mass ledger, moment diagnostics, force/deposition error |
| `FieldHamiltonian` | deposited density, field discretization, periodic kernel | discrete $U_h$, compatible $\delta U_h/\delta X$, symmetry/self-force residuals |
| `AdaptationProposal` | local error indicators and budget | block splits / degree proposals with predicted cost, causality and hysteresis |
| `ConservativeTransfer` | old/new representation, mass/energy contract | before/after moments, explicit lost information and transfer error |
| `SymplecticAtlasAudit` | local charts, action edges, periods | H1–H3 conditions, two-form defect, seam jumps, fallback fraction, periods |
| `ThermoOperator` (future) | energy/entropy variables, Poisson/dissipative tensors | degeneracy, entropy-production, positivity and open-system source/flux ledgers |

Separately track **physical state** ($x,p,\rho$, gas thermodynamics), **representation geometry** (label elements, curves/surfaces, polynomial degree), **physical measures** (mass, compositions), and **diagnostic metadata**. Avoid hidden changes in gravitational-source ownership or global timestepping. Use stable identifiers for element lineage and remap version when writing HDF5 checkpoints.

A minimal C++ development strategy is: standalone research library → single-process 2D golden tests → parallel/production-grade data layouts → isolated CHUÍ compile-time feature flag → integration with CHUÍ gravity after validation. No production source changes are included in this dossier.

---

# 12. Alternative future mathematics and fundamental limits

## 12.1 What could be mathematically original?

Potential originality lies not in using splines, $hp$-refinement, generating functions, DEC or symplectic variational mechanics separately. It would require **a new demonstrable property**, such as: (a) a globally compatible, computationally efficient higher-dimensional Lagrangian carrier; (b) a rigorous invariant-aware transfer with a useful approximation theorem; (c) a semidiscrete sheet–field Hamiltonian with a better proven/observed gravity symmetry tradeoff; or (d) a validated physical-observable error estimator driving cheaper local refinement.

Existing prior work on ColDICE, Hahn–Angulo phase-space elements, geometric-optics generating families, structure-preserving PIC, compatible/mimetic discretization and adaptive variational mechanics must be examined before any historical priority claim.

## 12.2 Why mathematical elegance can be the wrong numerical choice

The exact-atlas prototype demonstrates the central lesson: preserving an invariant by construction may cost hundreds of times more than an accurate unconstrained approximation. A method must demonstrate either **necessary physical fidelity** or **better accuracy per unit cost**. Fallback cells and conditional assumptions must count in its true failure rate. Avoid equating local exactness with the global symplecticity of the evolving nodal map.

## 12.3 GENERIC remains open research, not abandoned

A future full DUNE framework could combine Hamiltonian/Poisson evolution and appropriate GENERIC reversible–irreversible thermodynamics, while geometric adaptation changes discrete degrees of freedom. This would require proving the correct degeneracy and balance relations **after each representation change**, or explicitly quantifying the defect. Cooling with escaping radiation, chemistry and cosmic expansion are not closed systems without additional reservoirs or fluxes. This ambitious question remains the *long-range Maker/Life-of-Water program*, not the target of the next gravity benchmark.

---

# 13. Provenance, reproduction and archive map

## 13.1 New breakthrough archive — precise locations

- `shai-hulud-fable-breakthrough-results(1).zip`
  - `work/fable_breakthrough/README.md`, `RELEASE_NOTES.md`
  - `work/fable_breakthrough/research/method_decision.md`: decision, positive/negative evidence and next pass/fail benchmark.
  - `work/fable_breakthrough/research/atlas_derivation.md`: conventions, theorem statements, H1–H3, proof claims, failure and fallback conditions.
  - `work/fable_breakthrough/research/conventions_and_baselines.md`: comparisons and normalization.
  - `work/fable_breakthrough/src/shsheet/`: research Python implementation.
  - `work/fable_breakthrough/tests/`: 30 regression tests.
  - `work/fable_breakthrough/experiments/`: individual drivers.
  - `work/fable_breakthrough/results/SUMMARY.md`, `results/*.json`, `results/figures/`: measured outcomes and figures.

### Reproduction commands (in extracted source root)

```bash
cd work/fable_breakthrough
PYTHONPATH=src python3 -m pytest -q tests
cd experiments
python3 exp_a_atlas.py --quick
python3 exp_b1_accumulation.py postfold --quick
python3 exp_b2_adaptive.py --quick
# The VP run also requires the appropriate reference snapshots:
python3 exp_c_reference.py 512
python3 exp_c_reference.py 1024
python3 exp_c_vp.py --quick
```

The experiment package's README has the complete full-duration commands. The quick versions are not interchangeable with the published full JSON tables. The source reports 30/30 passed and includes environment/hardware hashes; **we reran the regression command for this dossier and also obtained 30 passed**. We did not independently repeat every full-duration experiment or formally prove Theorem 5.

## 13.2 Previous two source archives

- `shai_hulud.zip`: Fable's 31-page original manuscript, 1D/2D action-corrected prototypes, proof ledger and saved experiments. Historical source: no self-gravity in that first package.
- `shai-hulud-lab(2).zip`: DeepSeek formal audit, restricted averaging no-go, seven experimental scripts and recorded results.
- `chatgpt-export-2026-11-16T11-58-15-556Z.zip`: earlier discussion exported for provenance.
- `chatgpt-Branch · Chuí Hulud Module Idea.zip`: newer project discussion export. Use as context/history, not mathematical evidence.

## 13.3 SHA-256 for the original archives

| Artifact | SHA-256 |
|:--|:--|
| `shai_hulud.zip` | `67a34da6f43a893cb6f574e7bd12dbbb213d7fd8bc23b9713742c7db0aa7cddc` |
| `shai-hulud-lab(2).zip` | `df6066f5e9a5ed9ed2f55d248e2d9f6960c67dfd72bfc837717596912fb7b108` |
| `chatgpt-export-2026-11-16T11-58-15-556Z.zip` | `cd608ae6eeaeafef10bb6b188c12e1462ee3e2b2e421b5aef1fd00d2ddb20389` |
| `shai-hulud-fable-breakthrough-results(1).zip` | `6deae91abc655c3a177771d421b19d2206058c279deea4f889b562c8e3e2b017` |
| `chatgpt-Branch · Chuí Hulud Module Idea.zip` | `fed0e894e58fadf522264ef7c1212b8416ecbc3a891f4ebea76805797e6af3d3` |

## 13.4 Documentation-to-evidence mapping

**New conditional mathematical construction:** `atlas_derivation.md` §3 Theorem 5 + `tests/test_atlas.py`, `results/exp_a_atlas.json`, `results/exp_b1_*.json`.

**Negative OT, atlas cost, refinement decision:** `method_decision.md` + `results/exp_b2_adaptive.json`, `results/exp_cost.json`, `results/exp_c_vp.json`.

**Force compatibility:** `results/exp_c_audit.json`, `results/exp_c_vp_timing.json`, `src/shsheet/pm.py`, `src/shsheet/vp.py`.

**3D local chart limitations:** `results/exp_d_3d.json`, `src/shsheet/sheet3d.py`.

**DeepSeek no-go theorem and GENERIC:** old DeepSeek `research/discrete_method.md`, `research/proof_ledger.md`, `experiments/exp02_symplectic_nogo.py`, `experiments/exp07_generic_oscillator.py`.

For literature, consult the original manuscripts and verify every DOI directly before reproducing an originality claim. No new prior-art novelty search was performed as part of this dossier update.

---

# 14. Instructions for the next research agent

When resuming, attach/read **this v1.1 dossier** and the three primary source archives (`shai_hulud.zip`, `shai-hulud-lab(2).zip`, `shai-hulud-fable-breakthrough-results(1).zip`). Treat the new Fable method decision as the **current empirical priority**, and older OT/action-first material as a **historical hypothesis**.

**Suggested first assignment:** *Implement local block-structured high-order phase-sheet $h$-refinement in the existing 2D periodic Vlasov–Poisson research solver. Preserve exact mass partition at coarse/fine boundaries, reconstruct new state using the quintic carrier, audit action/caustic/force and transfer errors, and compare with N-body PM at equal wall time, equal memory and at least two PM force resolutions. Do not use a reference/oracle to drive refinement online. Report failed triggers, regression failures and performance limits honestly.*

**Parallel mathematical assignment (not a prerequisite):** derive and experimentally validate an adjoint/variational sheet-to-field gravitational force from a common semidiscrete energy. Include the true test of momentum, self-force and action invariants, rather than accepting slogans about variational conservation.

**Independent speculative research:** generating families across folds, DEC/cohomology period ledger, conforming 3D atlas closure, constrained $hp$ approximation, multiresolution manifold compression, GENERIC-compatible irreversible physics. They are not present engine capabilities.

**Permanent constraints:** don't modify production CHUÍ until validated; don't call OT generally useless; don't call a conditional agent proof peer reviewed; don't compare error across different PM fields as though it were purely reconstruction error; don't mistake periods for full symplecticity; don't publish a performance claim without measured common-baseline CPU/memory and science observables.

---

# 15. Status verdict and next irreversible decision

**Supported direction:** High-order phase sheets with sheet quadrature, action diagnostics and early carrier-based refinement offer a meaningful, limited 2D research path. A separate exact 2D Lagrangian atlas construction is mathematically interesting under its conditions, but its prototype overhead and self-gravity performance do not justify default activation. OT-based repeated label relocation has failed the relevant first cost/error tests and has been moved to the optional IX-FORGE research wing.

**Unresolved:** local nonuniform refinement, force-consistent variational nodal coupling, converged 2D physical advantage, 3D conforming sheet representation, expanding cosmology, genuine particle release, GENERIC gas coupling, and novelty/publication-level proofs.

**Next decision gate:** after local quintic $h$-refinement plus refined-PM benchmarks, either (A) demonstrate a reproducible accuracy/cost advantage and invest in 3D, or (B) retain the sheet as a memory-efficient and geometric-analysis specialized mode while standard N-body remains the gravity default. A negative answer is a valid scientific outcome.

> **The Maker's principle:** *Preserve elegant mathematical structure where it improves science; measure physical error and computation before making it the default.*

---

# Appendix A. Historical first-mission mathematics and prior research chronology

The following summarizes the **initial** Fable/DeepSeek research and helps trace how the design evolved. It is historical context; its roadmap has been superseded by §9. The full original v1.0 dossier is preserved separately in the continuity archive.

## A.1 Earlier Fable research: the 31-page manuscript

The first Fable archive explored a 1D action-corrected interpolant and local 2D generating-function reconstruction, with optimistic action-period and normal-error results under prescribed flows. In 1D at specified node budgets, the manuscript reported adaptive cubic max normal errors approximately $1.2\times10^{-4}$ and $1.3\times10^{-4}$ for collapse/chaos examples, compared with action-corrected values $4.3\times10^{-6}$ and $2.6\times10^{-6}$. Those improvements applied to a particular **normal** metric and were not demonstrated as improvements in self-gravitating physical accuracy or CPU time. Its 2D local generating-function chart could preserve certain geometric invariants but suffered a momentum-accuracy penalty, and a global conforming atlas remained open **in that first archive**; the newer Fable theorem subsequently advances that question conditionally.

## A.2 Earlier DeepSeek research: correction and falsification

DeepSeek's work studied separate linear positive-weight remaps, 2D pullback defects, the kinetic-energy variance identity and a GENERIC oscillator. Its graded-mesh experiment found that using freshly sampled exact values could improve the approximation while remapping from a coarse old interpolant could make it worse. Fable's later spline result shows that high-order carrier-based refinement can avoid that penalty **in some cases**, without refuting DeepSeek's restricted counterexample.

## A.3 Original grand long-term SHAI-HULUD formulation

Earlier discussion speculated about a hybrid discretization where collisionless sheets, released N-body particles and eventually compressible gas would share gravity; Hamiltonian/Poisson dynamics would govern appropriate reversible subsystems, GENERIC dissipative dynamics would govern suitable irreversible subsystems, and SPICE would provide explicit numerical contracts. A schematic (non-derived) optimizer over representations and geometry was proposed, but scientific identity was deliberately shifted away from 'administrator' to **a new numerical method**. That long-range programme remains an ambition, not a consequence of the recent 2D benchmark.

## A.4 Historical action-monitor issue

The old manuscript used an $L^1$-style objective $\int\|C\|h^{3-d}\,dq$ with constraint $N=\int h^{-d}\,dq$ and then claimed a monitor exponent $d/(d+3)$. These do not follow from each other as written; for $d=3$ the integrand is independent of $h$. The correct monitor depends on the actual integrated error metric and degrees-of-freedom counting. This inconsistency was flagged before the new Fable breakthrough; **it has not been retroactively proven sound by the later results**. Prefer the empirically stronger fourth-difference monitor while deriving new theory.

## A.5 Why OT remains in the archive

The distinction between **invertible label-space relabeling** and **many-to-one Laguerre assignment/averaging** is fundamental and worth preserving. Fable's r-adaptation is not refuted by DeepSeek's no-go for linear averaging, but it failed to be a compelling default experimentally. OT may still be useful for moving-mesh hydrodynamics, domain redistribution or other future problems and should be evaluated there from scratch.


# Appendix B. Earlier proof and experiment detail retained from v1.0

The two sections below reproduce the **historical Fable/DeepSeek first-mission inventories and experimental record** with their old headings changed to B.1/B.2. They are retained as dated sources and **do not override v1.1 decisions**.


## B.1 Original Fable first mission


**Primary supplied archive:** `shai_hulud.zip`. Root after extraction: `shai_hulud/`. The archive itself is a research package, **not** a merged production CHUÍ implementation.

### 5.1 File map

| Source file | Role |
|:--|:--|
| `manuscript/shai_hulud.pdf` | Compiled 31-page mathematical research manuscript |
| `manuscript/shai_hulud.tex`, `sec_*.tex` | LaTeX manuscript sources and result tables |
| `proof_ledger.md` | Claims labelled established, new derivation, conditional, numerical, open |
| `prototype/sheet1d.py` | 1D phase sheet, action-corrected interpolation, KDK/action updates and label remapping |
| `prototype/sheet2d.py` | 2D label manifold / 4D phase-space prototype, generating-function elements and periodic Monge–Ampère solver |
| `prototype/experiments_1d.py`, `experiments_2d.py` | Experimental drivers |
| `prototype/verify_propositions.py` | Eleven reported symbolic/numerical checks |
| `results/exp1d_*.json`, `results/exp2d.json` | Saved measured outcomes and figure sources |
| `README.md` | Scope and reproduction instructions |

The manuscript's proof ledger labels “new derivation” as **proved in the agent-authored manuscript**, not as historically original. Its literature check was limited, and its mathematical results remain candidates for independent specialist review.

### 5.2 Proposed numerical construction

- Carry the phase-space state and action $\Sigma$ at vertices.
- Advance with an exactly generated KDK carrier under an externally specified or correctly interpolated potential.
- Construct a smooth monitor in label space from a geometrically motivated action defect/cubic form.
- Solve label-space OT to redistribute sampling while transforming physical mass correctly.
- Reconstruct via $AC(m,r)$ in 1D and local generating-function elements in 2D+.
- Record action periods, 2-form defects, physical errors, mass balance and adaptation errors.

#### Strongest reported 1D result

The reported one-dimensional experiments compare action-corrected interpolation against ordinary cubic interpolation under repeated remapping and prescribed Hamiltonians. Reported examples:

| Scenario | Ordinary adaptive cubic, max normal error | Action-corrected $AC(4,1)$, max normal error | Interpretation |
|:--|--:|--:|:--|
| Collapse, 1024 vertices | about $1.2\times10^{-4}$ | about $4.3\times10^{-6}$ | Roughly 28-fold lower **normal** error |
| Chaotic external driving, 2048 vertices | about $1.3\times10^{-4}$ | about $2.6\times10^{-6}$ | Roughly 50-fold lower **normal** error |

The archived README additionally reports action-period errors $\lesssim6\times10^{-15}$ through repeated remaps in tested cases and normal-order improvements. **Important limitation:** improvements in the normal component do not imply equivalent reductions in full $(x,p)$ error, force error, runtime or memory. Tangential errors and degeneracy near hairpins remain relevant. Smooth-twist experiments showed little/no benefit from adaptivity.

#### Restricted 2D result

In two-dimensional label space embedded in four-dimensional phase space, the implementation uses a generating function **inside a single admissible chart**. The reported circulation defect for suitable generating-function elements reached quadrature/roundoff levels, often at a **momentum accuracy penalty** relative to unconstrained high-order interpolation. One earlier comparison at $128\times128$ cites ordinary biquintic $p$ error $2.74\times10^{-10}$ with circulation defect $1.72\times10^{-12}$ versus a front-5 generating-function element with $p$ error $1.88\times10^{-8}$ and defect $1.36\times10^{-14}$. Interpretation: significantly stronger structural constraint, but worse momentum approximation in that regime. Do not characterize it as a universal victory.

### 5.3 What Fable did **not** achieve

- No globally conforming exact Lagrangian carrier across fold caustics in $d\ge2$.
- No proof of long-time stability under unboundedly many remaps; a sampled linearized spectral-radius check is not a full proof.
- Some convergence claims are conditional on Lipschitz stability assumptions for reconstruction not established in the moving-frame general case.
- No self-consistent Vlasov–Poisson or TreePM cosmological run; the EdS example uses a prescribed potential.
- No 3D cosmological phase sheet, particle release or realistic baryonic physics.
- No comprehensive prior-art audit establishing novelty of action-based interpolation in geometric optics, wavefront construction or geometric integration.

---


## B.2 Original DeepSeek audit


**Primary supplied archive:** `shai-hulud-lab(2).zip`. Root after extraction: `reports/`, `research/`, `experiments/`, etc. The `inputs/deepseek_01_unverified.txt` and `inputs/deepseek_02_unverified.txt` are **earlier drafts, not verified research products**; the later Mission 01 audits and corrects them.

### 6.1 File map

| Source file | Role |
|:--|:--|
| `reports/mission_01.md` | Primary audit, theorems, experimental outcomes, limitations |
| `reports/next_research_questions.md` | Prioritized, falsifiable next experiments Q1–Q10 |
| `research/discrete_method.md` | Averaging no-go, kinetic identity, P1 two-form defect, algorithms |
| `research/optimal_transport.md` | Laguerre OT, measure traps, monitor exponents, numerical comparison |
| `research/formal_foundations.md` | Sheet geometry, cosmological energy and GENERIC corrections |
| `research/proof_ledger.md` | Status ledger and audit IDs |
| `research/sources.md` | Twenty DOI/arXiv-checked references (mostly bibliographic/abstract-level verification) |
| `experiments/exp01_...py` through `exp07_...py` | Seven reproducible scripts with JSON results |
| `experiments/shai_core.py`, `shai_geom.py` | Shared numerical/math helpers |

### 6.2 The key mathematical findings

**(a) Restricted no-go theorem:** Positive, row-stochastic, mass-weighted **linear averaging** is symplectic only for permutations/trivial duplications. This sharply restricts one obvious form of remap but does **not** prohibit all structure-aware reconstruction.

**(b) Exact kinetic identity:** Averaging reduces represented bulk kinetic energy by a nonnegative within-cell velocity-variance term (Section 3.8), correcting the earlier drafts' sign.

**(c) Piecewise-linear defect:** A continuous Lagrangian sheet may have a nonzero discrete two-form defect after piecewise-linear interpolation. The leading term depends on second derivatives of the phase-space embedding; a universal bound based only on $D^3F$ is contradicted by a quadratic counterexample.

**(d) A special exact 2D identity:** For

$$
F_t(q)=(q+t\nabla\varphi(q),\nabla\varphi(q)),
$$

the piecewise-linear pulled-back two-form defect is the antisymmetric part of the discrete momentum gradient and is **independent of $t$** for this family. Spatial orientation/determinant, not that two-form defect alone, detects the caustic. This is not a claim about arbitrary Hamiltonian trajectories.

**(e) Monitor separation:** For piecewise-linear scalar interpolation, the reported optimal local density for integrated $L^2$ solution error scales as $\rho\propto\|D^2 f\|^{2d/(d+4)}$ under standard quasiuniform/shape assumptions. That differs from maximum-error equidistribution, quantization monitors and sheet two-form defect monitors. The proposed defect-specific density $\rho\propto\|D^3S\|^{2d/(d+2)}$ appears in the next-research plan as a **prediction to test**, not an established 2D victory.

**(f) GENERIC oscillator corrections:** The correct entropy gradient for $S=C\ln u$ is $C/u$. A reported full-system implicit-midpoint method conserved the oscillator's total energy up to floating-point error and showed second-order convergence; explicit damping did not exactly conserve it. This is a very limited thermodynamic reference, not cosmological gas physics.

### 6.3 Recorded seven-experiment overview

| ID | Purpose | Most relevant archive-reported observation |
|:--|:--|:--|
| exp01 | Conservative averaging identity | Rational-arithmetic residual zero in test cases; two atoms $K:1\to0$ |
| exp02 | Restricted symplectic no-go | Duplication defect zero; nontrivial averaging has nonzero defect |
| exp03 | Sheet defect / derivative order | Counterexample with $D^3F=0$ yet nonzero PL defect |
| exp04 | 1D sheet baselines | Approximation and singularity scaling; 1D 2-form is vacuous |
| exp05 | 2D sheet in 4D phase space | Reported near-first-order PL two-form defect, independent of $t$ in selected family; caustics tracked separately |
| exp06 | Monitor and graded-remap comparisons | Grading helps with freshly known values; reinterpolation may worsen error |
| exp07 | GENERIC oscillator | Energy-corrected implicit prototype and second-order numerical behavior |

#### The decisive exp06 comparison

At 128-by-128 samples for a prescribed 2D Gaussian-like test sheet, the archived global RMS errors are:

| Arm | How sampled | RMS error |
|:--|:--|--:|
| A | Uniform mesh, exact values at its nodes | **0.0047227683** |
| B | Graded mesh, **fresh exact values** at its nodes | **0.0017542201** |
| C | Graded mesh, values reconstructed from Arm A | **0.0056246100** |

So the ideal graded geometry reduced this error by approximately 63%, while **remapping an existing approximation made it roughly 19% worse than Arm A**. Grading alone cannot create missing information; representation transfer must be part of the method's accuracy analysis. The source explicitly identifies this as prescribed grading; it does **not** establish a measured OT speedup over a competitive moving-sheet solver.

---

