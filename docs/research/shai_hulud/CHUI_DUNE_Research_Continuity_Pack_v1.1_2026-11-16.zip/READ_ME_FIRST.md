# PROJECT DUNE / SHAI-HULUD — Research continuity v1.1

**As-of:** 16 November 2026, Brazil local date. **Research status:** experimental numerical methods; no production CHUÍ integration; no peer review.

## Where to start

1. `SHAI_HULUD_Project_Dossier_v1.1_2026-11-16.pdf` is the readable **authoritative current dossier** (29 pages).
2. The same content is in the editable `.md`; figures are stored under `dossier_assets/`.
3. `original_sources/shai-hulud-fable-breakthrough-results(1).zip`: new Fable 2D self-gravity, atlas, OT/refinement tests, proofs, 30 unit tests. **First read:** `work/fable_breakthrough/research/method_decision.md`, then `research/atlas_derivation.md` and `results/SUMMARY.md`.
4. `original_sources/shai_hulud.zip`: first Fable action-corrected phase-sheet manuscript/prototypes. Historical first mission.
5. `original_sources/shai-hulud-lab(2).zip`: DeepSeek restricted averaging/symplectic no-go, experiments and GENERIC oscillator.
6. The v1.0 dossier is retained in `history/` but has an outdated **critical-path priority** and incorrectly predates the new 2D self-gravity evidence. Use v1.1 for the current roadmap.

## Five rules to remember

- **SHAI-HULUD is the central new numerical research method, not an administrator.** MENTAT is the controller.
- **Default collisionless research engine:** quintic spline phase sheet, sheet quadrature, cheap action tracking and early local h-refinement. Local block refinement is the NEXT goal, not a completed feature.
- **OT r-adaptation was unsuccessful in the tested gravity benchmarks**, so it leaves the gravity critical path; retain Laguerre/OT as IX-FORGE for possible gas/moving-mesh experiments. Do not generalize the failure beyond that tested scheme.
- **IX-GRAVITAS is the new gravity-oriented research pillar:** semidiscrete variational/compatible field coupling and consistent sheet quadrature/force construction. This is a design hypothesis, not implemented.
- **Theorem 5 (Fable):** proposed conditionally C0-conforming, cell-wise exactly Lagrangian carrier in 2D under H1–H3; expensive and with fallbacks. It does not prove symplecticity of full evolving nodal dynamics, does not give a 3D conforming carrier, and was not formally peer reviewed.

## Immediate next research task

Run matched 2D self-gravitating Vlasov–Poisson experiments using **local block-structured high-order h-refinement**, with a state-only early trigger and high-order carrier transfer. Compare to particle PM at equal wall time, equal peak memory, and across at least two sufficiently refined PM field resolutions. Include force error, density, position, caustic structure, momentum, energy, action periods, seam defects and fallback rates. Preserve negative results. Do not modify ordinary CHUÍ without independently passing gates.

## Research continuity

The ZIP keeps source archives byte-for-byte, including failed experiments and logs. `SHA256SUMS.txt` records integrity digests. The chat exports are historical discussion data, **not** proof. For scientific novelty, audit existing ColDICE/Hahn–Angulo and action-/generating-function/mimetic/variational field literature before making originality claims.
