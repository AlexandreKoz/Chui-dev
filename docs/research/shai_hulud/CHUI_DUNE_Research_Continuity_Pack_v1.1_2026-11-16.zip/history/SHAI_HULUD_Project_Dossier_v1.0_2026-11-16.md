---
title: "PROJECT DUNE | SHAI-HULUD"
subtitle: "Master research dossier, mathematical status, and continuity specification"
author: "CHUÍ experimental numerical research programme — consolidated working record"
date: "16 November 2026"
lang: en-US
geometry:
  - a4paper
  - margin=22mm
fontsize: 10pt
colorlinks: true
linkcolor: "243B53"
urlcolor: "1769AA"
toc: true
toc-depth: 3
numbersections: false
---

> **Status:** Research design and prototype audit, **not** a peer-reviewed paper or a production solver. This document preserves the project as discussed through 16 November 2026 and consolidates evidence from the supplied Fable and DeepSeek archives. It deliberately separates established mathematical facts, derivations reported by the agents, reproduced or reported numerical checks, hypotheses, and open problems.

# Read this first: continuity capsule

**Project:** CHUÍ, a C++ cosmological simulation project with TreePM gravity, patch-AMR/Godunov development, MPI/OpenMP, HDF5 and a long-term multiphysics roadmap. **DUNE** is a proposed optional, relatively low-profile experimental numerical-research family in that codebase. **SHAI-HULUD**, named after the sandworms of *Dune*, is its central and most ambitious mathematical method—not a sandworm visualization and **not merely an administrator selecting other solvers**.

**Long-term vision:** Structure-aware evolution of matter **and of its computational representation**. Principal ingredients: (1) Hamiltonian/Poisson dynamics; (2) cold dark-matter phase-space sheets; (3) optimal-transport-guided adaptation of computational sampling/geometry; (4) GENERIC/metriplectic descriptions of appropriate irreversible physics; and (5) transfer operators with explicit conservation, geometric, thermodynamic and information-loss contracts. **SPICE** is the reusable numerical backbone (also a nod to electrical-engineering circuit SPICE); **LITTLE MAKER** reshapes local numerical geometry; **IX** supplies Laguerre/OT machinery; other Dune modules have defined roles below.

**Immediate research priority:** Do **not** attempt the entire ecosystem at once. Study **Hamiltonian phase-space sheets + geometric adaptation + mathematically controlled reconstruction**, initially without gas, GENERIC, full TreePM, or particle release. The unresolved bottleneck is whether a discrete sheet can move/refine its degrees of freedom without accumulated remap error overwhelming any gain from adapting the geometry.

**What already exists in the supplied research archives:** Fable produced a 31-page LaTeX/PDF manuscript and reference Python prototypes for 1D and restricted 2D action-aware reconstruction; DeepSeek produced a separate mathematical audit, restricted symplectic no-go theorem, corrected interpolation-defect formulas, seven experimental scripts and GENERIC checks. **There is no demonstrated self-gravitating cosmological SHAI-HULUD solver; no established scientific novelty, production performance advantage, or globally conforming structure-preserving 2D/3D reconstruction across caustics.**

**Highest-priority next tests:** (a) correct the monitor derivation; (b) directly compare Fable's action-corrected reconstruction with DeepSeek's ordinary remap under exactly matched reference data and budgets; (c) solve/characterize multi-chart gluing across 2D caustics; (d) reproduce/test the 3D two-form defect; (e) only then attempt self-consistent gravitational evolution. Continue the rigorous proof ledger and treat all model-derived theorems as **claims requiring independent expert verification**.

---

# 1. Origin, purpose, and design decisions

## 1.1 How the idea started

The original idea was an Easter-egg module called **CHUÍ-HULUD** or **SHAI-HULUD** inside CHUÍ. The intent was **never** to add a joke creature or a visually recognizable worm to a simulation. The intent was to hide a *genuinely useful, exceptionally ambitious and mathematically elegant research capability* in an otherwise conventional-looking cosmological simulator, with a broader family of experimental modules inspired by *Dune*. Their responsibilities should reflect the meaning of their names in the fictional setting.

The long-term aspirational target is a **novel numerical method**, not a giant switch statement over well-known solvers. The experimental family should be opt-in, isolated from the stable solver, reproducible, and scientifically documented even if it is absent from the public-facing feature brochure. The project is open source: “secret” therefore means non-promotional/experimental, **not hidden from code inspection or concealed in scientifically published results**.

## 1.2 Fundamental design choice: The Maker must do mathematics

An early architecture made SHAI-HULUD a supervisor that would choose phase sheets, particles, AMR or Laguerre cells according to error and cost. That remains potentially useful as the **MENTAT** controller, but is **not sufficient** to merit the name *The Maker*. The agreed research identity is:

> **SHAI-HULUD is the experimental numerical method that attempts to couple appropriate physical evolution with adaptive computational representation under rigorously stated geometric, conservation and thermodynamic conditions.**

The selection of an economical representation is a later capability and an auxiliary optimization problem. It must not be confused with the main research contribution.

## 1.3 The Dune analogy matters

In Dune lore, adult sandworms are central to the lifecycle that produces spice; sandtrout, or **Little Makers**, are especially important in reshaping and drying Arrakis. Thus: LITTLE MAKER handles local geometric adaptation; ARRAKIS is the computational environment; SHAI-HULUD is the deepest evolution method; **SPICE** is the valuable reusable mathematical capability that emerges from the ecosystem. SPICE deliberately alludes as well to *Simulation Program with Integrated Circuit Emphasis*, familiar from electrical engineering, and is not required to implement circuit simulation.

## 1.4 Explicitly settled principles

1. **Collisionless dark matter is Hamiltonian whether represented by a sheet or N-body particles.** A phase sheet and Hamiltonian mechanics are **not** two mutually exclusive runtime choices.
2. Initially cold, sufficiently regular collisionless matter may be represented as a $d$-dimensional manifold inside $2d$-dimensional phase space. This does **not** generally describe warm, fully six-dimensional distributions.
3. The initial science target is a periodic cosmological cube. Smooth regions could use sheets; strongly mixed regions might eventually release into particles. Gas remains governed by its own suitable fluid and thermodynamic equations and couples gravitationally.
4. **Physical evolution**, **numerical reparameterization**, **finite-dimensional interpolation/projection**, and **physical irreversible dissipation** must be distinguished in equations and code.
5. OT is a tool for generating and controlling geometry; it does **not** by itself guarantee symplecticity, mass fidelity or improved hydrodynamics.
6. GENERIC is relevant to suitable dissipative subsystems, but does **not** need to be forced onto ideal collisionless cold matter.
7. Exact preservation, positivity, accuracy, high order and changing topology may be competing requirements. A failed theorem/counterexample is a useful research outcome.
8. All modules must remain optional. Disabling DUNE should leave normal CHUÍ behavior unchanged; enabled methods must be recorded in outputs and restart metadata.

---

# 2. The intended physical simulation

## 2.1 The eventual cosmological cube

Let the computational spatial domain be a periodic three-torus $\mathcal X=\mathbb T^3$, initially populated by cold dark matter with Lagrangian label domain $\mathcal Q$ and measure $\mu_0$. The physical sheet embedding is

$$
F_t:\mathcal Q\longrightarrow T^*\mathcal X,\qquad F_t(q)=(x(q,t),p(q,t)).
$$

The **phase-space mass distribution** is a pushforward measure

$$
\mu_t=(F_t)_\#\mu_0,
$$

and the spatial density is its pushforward under the projection $\pi_x:(x,p)\mapsto x$:

$$
\rho_t=(\pi_x\circ F_t)_\#\mu_0,
\qquad
\rho(x,t)=\int_{\mathcal Q}\rho_0(q)\,\delta_D[x-x(q,t)]\,d^3q
$$

in the distributional sense. Multiple values of $q$ may map to the same spatial $x$ after shell crossing. The spatial projection can develop caustics while the exact sheet in full phase space can remain geometrically regular under suitable Hamiltonian flow assumptions.

## 2.2 Anticipated spatial regimes

| Region | Candidate representation | Why | Main caution |
|:--|:--|:--|:--|
| Smooth, weakly deformed CDM | Adaptive high-order phase sheet | Retains fine-grained stream structure and suppresses particle shot noise | Cost of accurate geometry and density deposition |
| Filaments and first caustics | Refined/curved phase-space elements | Resolve strongly evolving mapping and multistream projection | Local chart conditioning, topology and force errors |
| Heavily mixed halo interiors | N-body particles after controlled release (future) | Avoid unbounded sheet refinement cost | Release discards sheet information and must not double-count mass |
| Smooth gas | Standard CHUÍ AMR, or later moving Laguerre cells | Appropriate Eulerian/ALE fluid representation | Conservative fluxes and physical thermodynamics |
| Shock/complex gas structures | Patch-AMR or other validated fluid representation | Robust shock capturing | A heuristic switch is **not** SHAI-HULUD's fundamental invention |

The representation of a physical component must not be confused with its evolution equation. Released dark-matter particles and sheet vertices still obey the appropriate gravitational Hamiltonian dynamics; both must source the same gravitational potential.

## 2.3 Schematic evolution step: not yet a validated algorithm

1. Construct density from all mutually exclusive mass carriers (sheet volumes, released particles, gas cells), avoiding mass duplication.
2. Compute gravitational potential/forces consistently using a shared solver (eventually CHUÍ TreePM).
3. Advance the collisionless component with a Hamiltonian/geometric time integrator and gas with suitable fluid/thermodynamic operators.
4. Measure geometry, physical errors, invariant residuals and computational cost.
5. If admissible, choose target sampling density, solve a label-space OT geometry problem, reconstruct the carrier and measure projection defects.
6. Refine/coarsen/release only when the appropriate physics and mathematical contracts allow it; retain provenance and a before/after defect budget.
7. Apply correct time-centering and gravitational coupling; write the state and diagnostics reproducibly.

The ordering above illustrates responsibilities; operator ordering, splitting error, time variable and force coupling need mathematical derivation and numerical validation.

---

# 3. Core mathematical foundations

## 3.1 Hamiltonian flow and the cold Lagrangian sheet

For canonical position $x$ and momentum $p$,

$$
\dot x=\frac{\partial H}{\partial p},\qquad
\dot p=-\frac{\partial H}{\partial x},\qquad
\omega=\sum_{i=1}^{d}dx_i\wedge dp_i.
$$

A **Lagrangian** sheet of dimension $d$ satisfies $F_t^*\omega=0$. Under an exact smooth symplectic Hamiltonian flow, this condition is retained if it held initially. It is not true for every conceivable initially cold/vortical distribution without conditions.

The canonical one-form is $\theta=p\cdot dx$ with $d\theta=dp_i\wedge dx_i=-\omega$ under the sign convention above. On a suitable local exact Lagrangian chart, one may write

$$
F_t^*\theta=d\Sigma_t,
$$

where $\Sigma_t$ is a generating action. On non-simply-connected domains, a **closed** one-form need not be globally **exact**; Poincaré/Liouville periods around noncontractible cycles must be carried explicitly. This matters on $\mathbb T^d$ and when joining local charts.

The exact continuous sheet evolves according to collisionless Vlasov/characteristic dynamics. **Preserving the geometric sheet in exact continuum mathematics does not imply that a finite-dimensional remesh is symplectic.**

## 3.2 Relabeling symmetry and transformed mass

Introduce a time-dependent, invertible label diffeomorphism

$$
q=T_t(\xi),\qquad \widetilde F_t(\xi)=F_t(T_t(\xi)).
$$

When labels change, the Lagrangian measure must be pulled back:

$$
\widetilde\mu_{0,t}=T_t^*\mu_0,
\qquad
\widetilde\rho_0(\xi,t)=\rho_0(T_t(\xi))\,|\det DT_t(\xi)|.
$$

Then, exactly at the continuum level,

$$
(\widetilde F_t)_\#\widetilde\mu_{0,t}=(F_t)_\#\mu_0.
$$

Relabeling changes how computational nodes sample the same sheet, not the represented physical matter. Merely moving nodes while retaining their old constant masses can change the distribution by an $O(1)$ amount. This “sampling is not mass” distinction is central to Fable's proposal.

A relabeling of the sheet should also not be conflated with a canonical transformation of all numerical node coordinates or with the many-to-one mass transfers from semi-discrete OT.

## 3.3 Cosmological canonical variables

For the chosen per-unit-mass convention in cosmic time, the candidate variables are comoving position $x$, canonical momentum $p=a^2\dot x$ and peculiar potential $\phi(x,t)$:

$$
H(x,p,t)=\frac{|p|^2}{2a(t)^2}+\phi(x,t),
\qquad
\Delta_x\phi=\frac{3}{2}\frac{\Omega_m H_0^2}{a}\,\delta(x,t)
$$

for a flat matter cosmology with the customary normalization and zero-mean source. The precise units, density normalization, component masses and force-interpolation convention must be verified against CHUÍ before integration. The Hamiltonian is explicitly time-dependent: ordinary mechanical energy is **not** a conserved invariant of the cosmological evolution.

An exact-gradient kick from a common scalar potential, followed by drift, is a canonical map for the specified potential. A KDK sequence can therefore transport action consistently **for the potential actually used at each kick**. This does not by itself prove exact energy or momentum conservation of a PM/TreePM self-gravitating discretization, especially when grid forces are obtained by interpolation of finite-differenced vector forces rather than differentiation of a common interpolated potential.

The appropriate total peculiar-energy balance is the Layzer–Irvine relation, schematically

$$
\dot E=-H_{\rm hubble}(2T+U),\qquad E=T+U,
$$

for its standard assumptions and definitions. A single-particle identity may include $\partial\phi/\partial t$ when the potential is self-consistent/time dependent. Do not substitute $\dot E=-2H_{\rm hubble}T$ for the total self-gravitating system.

## 3.4 Optimal transport: two fundamentally distinct constructions

**A. Smooth label-space OT (Fable research track).** Solve a Monge/Monge–Ampère problem for a diffeomorphic map of label space whose target is a **sampling monitor density** $M(q)$, while physical mass is reweighted through the pullback. For a normalized reference measure:

$$
T_\# d\xi=M(q)\,dq,
\qquad M(T(\xi))\det DT(\xi)=1.
$$

On a flat torus, an admissible quadratic-cost transport map can be represented by $T(\xi)=\xi+\nabla\varphi(\xi)$ modulo periodicity, satisfying a Monge–Ampère equation in a suitable regularity/convexity regime. OT provides a well-defined geometry selection/gauge; **it is not the mechanism that preserves the action**. That comes from how the discrete carrier is reconstructed.

**B. Semi-discrete Laguerre OT (DeepSeek audit track).** Assign positive source-measure masses to power-diagram cells

$$
L_j(w)=\{q:\ |q-z_j|^2-w_j\le |q-z_k|^2-w_k\ \forall k\},
$$

then make a finite target allocation and optionally average original state values. This is generally a many-to-one **coarsening**, not a smooth label diffeomorphism, and has a different geometric/conservation contract.

Ordinary Voronoi cells have $w_i=0$; Laguerre/power diagrams permit prescribed target cell masses under the appropriate OT assumptions. Generalized anisotropic metrics are a later research branch: they can produce nonplanar/nonconvex cell boundaries and much more complicated topology.

## 3.5 Structure-aware adaptation and generating functions

Fable's strongest constructive proposal carries nodal data

$$
(q_i,x_i,p_i,\Sigma_i),\qquad d\Sigma=p\cdot dx,
$$

through an exactly generated Hamiltonian update, solves a sampling-geometry problem, and reconstructs from action-compatible data. In one dimension it uses an **action-corrected** curve interpolation family, denoted $AC(m,r)$, with exact edge-action constraints. In higher dimensions it uses a generating-function representation **within an admissible local chart**.

The intended object is not simply an $x,p$ interpolant that happens to have a small defect, but a reconstruction whose representation carries as much geometric structure as its chart allows. In one dimension, remember that $F^*\omega=0$ is automatically true for every 1D map; action periods and chord/curve action error are the meaningful tests. In two-dimensional labels embedded in four-dimensional phase space, the pulled-back two-form provides a genuinely nontrivial test.

Crucially, action-period preservation of the **represented curve** does not establish that an arbitrary global map between the *full discrete nodal phase spaces* is symplectic. The two notions must never be treated as synonymous.

## 3.6 The first geometric defect and action monitors

Fable introduces an edge action defect

$$
\epsilon_e=\Sigma(q+e)-\Sigma(q)
-\frac12[p(q)+p(q+e)]\cdot[x(q+e)-x(q)],
$$

and a cubic tensor $C_{abc}=\omega(\partial_aF,\partial_{bc}F)$ for an exactly Lagrangian carrier. Its expansion is reported as

$$
\epsilon_e=-\frac{1}{12}C(e,e,e)+O(|e|^4).
$$

This can motivate a coordinate-robust local action monitor, but the **monitor exponent must be re-derived carefully** for the exact objective being minimized (see Section 7). An edge action error, a global $L^2$ solution error, a two-form defect and an $L^\infty$ tolerance generally imply **different** sampling densities.

DeepSeek shows a leading piecewise-linear interpolation defect on a 2D triangle that depends on $D^2F$, and for a graph sheet can be expressed using $D^3S$. A bound claimed solely in terms of $D^3F$ is false for general quadratic $F$; DeepSeek supplies an explicit counterexample. The norm/normalization of the defect (density versus integrated face flux) must be specified before comparing convergence rates.

## 3.7 Restricted discrete symplectic no-go theorem

DeepSeek studies nodal remapping of the form

$$
(x',p')=(Dx,Dp),\quad D\ge0,\quad D\mathbf1=\mathbf1,
$$

with positive nodal masses in $M=\operatorname{diag}(m_i)$ and $M'=\operatorname{diag}(m'_j)$. Preservation of the standard **mass-weighted discrete canonical form** requires

$$
D^TM'D=M.
$$

Under these assumptions, the nonnegative off-diagonal terms force every row of $D$ to select a single input. Thus only **permutations** or **physically trivial duplications with suitably divided masses** satisfy the condition. Genuine positive-weight averaging and strict coarsening fail. The proof is short and plausible, but should still be checked independently before a formal publication claim.

**Scope:** This theorem does not rule out action-based reconstruction, nontrivial canonical maps in equal dimension, nonlinear maps outside the stated class, or schemes that target exact sheet invariants instead of the global nodal symplectic form. Smooth dimension-reducing exact symplectic embeddings are obstructed by injectivity/rank, but finite-set or chartwise transfer requires a separately stated problem.

## 3.8 Exact kinetic-energy identity for averaged remaps

For a nonnegative transfer $P_{ij}$ with $\sum_jP_{ij}=1$, let $m'_j=\sum_i m_iP_{ij}$, and define $v'_j=\frac{1}{m'_j}\sum_i m_iP_{ij}v_i$. Then

$$
K'=K-\frac12\sum_{ij}m_iP_{ij}|v_i-v'_j|^2\le K.
$$

The lost resolved bulk kinetic energy is exactly the within-cluster velocity variance. It is **not** automatically physical heat. One may carry that dispersion as an unresolved moment under a carefully defined closure. Earlier draft claims of increasing kinetic energy or exact conservative symplectic averaging were disproven in DeepSeek's audit.

## 3.9 GENERIC and metriplectic coupling — important but deferred

For an appropriate closed reversible–irreversible system:

$$
\dot z=L(z)\nabla E(z)+M(z)\nabla S(z),
$$

with Poisson/antisymmetric $L$, symmetric positive-semidefinite $M$ and degeneracy conditions

$$
L\nabla S=0,\qquad M\nabla E=0.
$$

When the full conditions hold, including Jacobi for the Poisson bracket, $\dot E=0$ and $\dot S\ge0$. Gas/radiation/chemical subsystems may be **open**, exchanging energy and entropy with external radiation or cosmological expansion; the closed-system equalities do not apply to arbitrary subsystem energies.

A finite-dimensional reference is the damped oscillator plus heat reservoir:

$$
E=\frac{p^2}{2m}+\frac{kq^2}{2}+u,\qquad
S=C\ln u,\qquad T=\frac{u}{C},
$$

with $v=(0,1,-p/m)^T$ and $M=\gamma T vv^T$. With $\nabla S=(0,0,C/u)^T$ this yields the intended dissipative friction and reservoir heating. DeepSeek corrected a draft's inconsistent $1/u$ gradient and showed that an explicit damped step does **not** conserve total energy exactly; an implicit-midpoint full-system prototype does so up to roundoff under that test's assumptions.

**Role:** WATER OF LIFE formulates appropriate irreversible physical models; SPICE exposes validated operators/contracts; SHAI-HULUD eventually researches compatible coupled geometric evolution. Do not merge GENERIC into the immediate phase-sheet proof problem before that proof problem is stable.

---

# 4. The complete DUNE experimental module family

This is a **conceptual design**, not evidence that any listed module is implemented in CHUÍ.

| Codename | Dune meaning | Intended scientific responsibility | Position in research plan |
|:--|:--|:--|:--|
| **SHAI-HULUD / CHUÍ-HULUD** | The Maker, great sandworm | Original structure-aware adaptive geometric/variational numerical method; ultimately compatible reversible–irreversible coupling | **Crown jewel; highest research ambition** |
| **SPICE** | Melange; also engineering SPICE | Structure-Preserving Interchange and Conservative Evolution: mathematical operators, invariants, discrete gradients, transfer contracts and diagnostics | Essential reusable foundation; independent of Maker |
| **LITTLE MAKER** | Sandtrout reshape Arrakis | Local element refinement/coarsening, curved sheet reconstruction, geometric monitor application | Core geometric adaptation |
| **ARRAKIS** | The computational world | Periodic geometry, spatial topology, coordinate maps, geometric queries and domain interoperability | Shared domain infrastructure |
| **IX** | Makers of advanced machinery | Laguerre/power tessellations, semi-discrete OT, label-space maps, geometry optimization | OT/geometric algorithms |
| **KWISATZ HADERACH** | Bridge across space and time | Verified transfers among compatible representations, conservative remapping, information-loss ledger | Transfer machinery |
| **MENTAT** | Specialized calculation and decisions | Error/cost/memory constrained numerical policies; representation-selection heuristics | Controller, **not the Maker** |
| **GUILD NAVIGATOR** | Prescience and navigation | Short-horizon numerical error forecasting and anticipatory refinement | Later optimization |
| **BENE GESSERIT** | Other Memory | Discrete adjoints, differentiability, sensitivities to initial conditions/physical parameters | Later research |
| **GOLDEN PATH** | Possible futures | Ensemble alternatives, uncertainty quantification, model comparison, controlled variations | Later research |
| **GOM JABBAR** | Adversarial test | Numerical falsification, stress cases, proof/claim audits and invariant torture tests | **Useful immediately** |
| **WATER OF LIFE** | Transformation | Thermodynamic closure, GENERIC/metriplectic irreversible physics, chemical/radiative exchanges | High ambition, **deferred** |

The list is not a command to implement twelve modules immediately. Research module names describe responsibilities, **not** necessarily a runtime dependency graph. Shared math primitives should not depend cyclically on particular solvers. Small independent experiments must remain possible.

## 4.1 Why SPICE comes directly below the Maker

SPICE was defined as a reusable library of numerical operators with **explicit mathematical contracts**: input domains and measures, conservation residuals, positivity/admissibility conditions, discrete Poisson and dissipative structures, derivative/adjoint availability, error estimators and failure modes. It can benefit ordinary CHUÍ AMR/Godunov, future chemistry or MHD **without activating SHAI-HULUD**. This is a planned outcome, not a present implementation.

The intended hierarchy is one of **scientific ambitions**, not hard complexity estimates: SHAI-HULUD is the hardest synthesis; SPICE is the foundation enabling reuse; IX, LITTLE MAKER and KWISATZ HADERACH carry specialized numerical methods; the remaining family explores other capabilities. WATER OF LIFE could itself become a research programme comparable in difficulty to the Maker.

## 4.2 Proposed software boundaries

A conceptual source layout, subject to actual CHUÍ ownership and build review:

```text
experimental/dune/
  core/              # numerical state descriptors, measures, contracts, event ledger
  spice/             # reusable operators and verification diagnostics
  shai_hulud/        # action-aware geometric and, eventually, metriplectic evolution
  ix/                # OT and Laguerre geometry
  little_maker/       # local refinement, curved elements, quality metrics
  arrakis/           # geometric domain adapters
  kwisatz_haderach/   # transfers / information-loss diagnostics
  water_of_life/     # GENERIC and irreversible physical models
  mentat/            # selection policies and cost models
  guild_navigator/    # short-horizon adaptation forecasts
  bene_gesserit/     # adjoints / sensitivities
  golden_path/       # ensemble uncertainty research
  gom_jabbar/        # stress tests, falsification and proof checks
```

**Integration rules:** keep existing gravity and timestep ownership; maintain stable MPI partition interfaces; do not silently modify source layouts/checkpoint schema; use concrete memory-efficient arrays in hot loops (SoA where warranted); bound geometric memory per region; record feature flags/algorithm versions in snapshots; test disabled-mode exact behavior; and require reproducibility. This is especially important as CHUÍ's existing multiphysics/AMR development evolves independently.

---

# 5. Fable research deliverables: action-aware reconstruction track

**Primary supplied archive:** `shai_hulud.zip`. Root after extraction: `shai_hulud/`. The archive itself is a research package, **not** a merged production CHUÍ implementation.

## 5.1 File map

| Source file | Role |
|:--|:--|
| `manuscript/shai_hulud.pdf` | Compiled 31-page mathematical research manuscript |
| `manuscript/shai_hulud.tex`, `sec_*.tex` | LaTeX manuscript sources and result tables |
| `proof_ledger.md` | Claims labelled established, new derivation, conditional, numerical, open |
| `prototype/sheet1d.py` | 1D phase sheet, action-corrected interpolation, KDK/action updates and label remapping |
| `prototype/sheet2d.py` | 2D label manifold / 4D phase-space prototype, generating-function elements and periodic Monge–Ampère solver |
| `prototype/experiments_1d.py`, `experiments_2d.py` | Experimental drivers |
| `prototype/verify_propositions.py` | Eleven reported symbolic/numerical checks |
| `results/exp1d_*.json`, `results/exp2d.json` | Saved measured outcomes and figure sources |
| `README.md` | Scope and reproduction instructions |

The manuscript's proof ledger labels “new derivation” as **proved in the agent-authored manuscript**, not as historically original. Its literature check was limited, and its mathematical results remain candidates for independent specialist review.

## 5.2 Proposed numerical construction

- Carry the phase-space state and action $\Sigma$ at vertices.
- Advance with an exactly generated KDK carrier under an externally specified or correctly interpolated potential.
- Construct a smooth monitor in label space from a geometrically motivated action defect/cubic form.
- Solve label-space OT to redistribute sampling while transforming physical mass correctly.
- Reconstruct via $AC(m,r)$ in 1D and local generating-function elements in 2D+.
- Record action periods, 2-form defects, physical errors, mass balance and adaptation errors.

### Strongest reported 1D result

The reported one-dimensional experiments compare action-corrected interpolation against ordinary cubic interpolation under repeated remapping and prescribed Hamiltonians. Reported examples:

| Scenario | Ordinary adaptive cubic, max normal error | Action-corrected $AC(4,1)$, max normal error | Interpretation |
|:--|--:|--:|:--|
| Collapse, 1024 vertices | about $1.2\times10^{-4}$ | about $4.3\times10^{-6}$ | Roughly 28-fold lower **normal** error |
| Chaotic external driving, 2048 vertices | about $1.3\times10^{-4}$ | about $2.6\times10^{-6}$ | Roughly 50-fold lower **normal** error |

The archived README additionally reports action-period errors $\lesssim6\times10^{-15}$ through repeated remaps in tested cases and normal-order improvements. **Important limitation:** improvements in the normal component do not imply equivalent reductions in full $(x,p)$ error, force error, runtime or memory. Tangential errors and degeneracy near hairpins remain relevant. Smooth-twist experiments showed little/no benefit from adaptivity.

### Restricted 2D result

In two-dimensional label space embedded in four-dimensional phase space, the implementation uses a generating function **inside a single admissible chart**. The reported circulation defect for suitable generating-function elements reached quadrature/roundoff levels, often at a **momentum accuracy penalty** relative to unconstrained high-order interpolation. One earlier comparison at $128\times128$ cites ordinary biquintic $p$ error $2.74\times10^{-10}$ with circulation defect $1.72\times10^{-12}$ versus a front-5 generating-function element with $p$ error $1.88\times10^{-8}$ and defect $1.36\times10^{-14}$. Interpretation: significantly stronger structural constraint, but worse momentum approximation in that regime. Do not characterize it as a universal victory.

## 5.3 What Fable did **not** achieve

- No globally conforming exact Lagrangian carrier across fold caustics in $d\ge2$.
- No proof of long-time stability under unboundedly many remaps; a sampled linearized spectral-radius check is not a full proof.
- Some convergence claims are conditional on Lipschitz stability assumptions for reconstruction not established in the moving-frame general case.
- No self-consistent Vlasov–Poisson or TreePM cosmological run; the EdS example uses a prescribed potential.
- No 3D cosmological phase sheet, particle release or realistic baryonic physics.
- No comprehensive prior-art audit establishing novelty of action-based interpolation in geometric optics, wavefront construction or geometric integration.

---

# 6. DeepSeek research deliverables: falsification and discrete-OT track

**Primary supplied archive:** `shai-hulud-lab(2).zip`. Root after extraction: `reports/`, `research/`, `experiments/`, etc. The `inputs/deepseek_01_unverified.txt` and `inputs/deepseek_02_unverified.txt` are **earlier drafts, not verified research products**; the later Mission 01 audits and corrects them.

## 6.1 File map

| Source file | Role |
|:--|:--|
| `reports/mission_01.md` | Primary audit, theorems, experimental outcomes, limitations |
| `reports/next_research_questions.md` | Prioritized, falsifiable next experiments Q1–Q10 |
| `research/discrete_method.md` | Averaging no-go, kinetic identity, P1 two-form defect, algorithms |
| `research/optimal_transport.md` | Laguerre OT, measure traps, monitor exponents, numerical comparison |
| `research/formal_foundations.md` | Sheet geometry, cosmological energy and GENERIC corrections |
| `research/proof_ledger.md` | Status ledger and audit IDs |
| `research/sources.md` | Twenty DOI/arXiv-checked references (mostly bibliographic/abstract-level verification) |
| `experiments/exp01_...py` through `exp07_...py` | Seven reproducible scripts with JSON results |
| `experiments/shai_core.py`, `shai_geom.py` | Shared numerical/math helpers |

## 6.2 The key mathematical findings

**(a) Restricted no-go theorem:** Positive, row-stochastic, mass-weighted **linear averaging** is symplectic only for permutations/trivial duplications. This sharply restricts one obvious form of remap but does **not** prohibit all structure-aware reconstruction.

**(b) Exact kinetic identity:** Averaging reduces represented bulk kinetic energy by a nonnegative within-cell velocity-variance term (Section 3.8), correcting the earlier drafts' sign.

**(c) Piecewise-linear defect:** A continuous Lagrangian sheet may have a nonzero discrete two-form defect after piecewise-linear interpolation. The leading term depends on second derivatives of the phase-space embedding; a universal bound based only on $D^3F$ is contradicted by a quadratic counterexample.

**(d) A special exact 2D identity:** For

$$
F_t(q)=(q+t\nabla\varphi(q),\nabla\varphi(q)),
$$

the piecewise-linear pulled-back two-form defect is the antisymmetric part of the discrete momentum gradient and is **independent of $t$** for this family. Spatial orientation/determinant, not that two-form defect alone, detects the caustic. This is not a claim about arbitrary Hamiltonian trajectories.

**(e) Monitor separation:** For piecewise-linear scalar interpolation, the reported optimal local density for integrated $L^2$ solution error scales as $\rho\propto\|D^2 f\|^{2d/(d+4)}$ under standard quasiuniform/shape assumptions. That differs from maximum-error equidistribution, quantization monitors and sheet two-form defect monitors. The proposed defect-specific density $\rho\propto\|D^3S\|^{2d/(d+2)}$ appears in the next-research plan as a **prediction to test**, not an established 2D victory.

**(f) GENERIC oscillator corrections:** The correct entropy gradient for $S=C\ln u$ is $C/u$. A reported full-system implicit-midpoint method conserved the oscillator's total energy up to floating-point error and showed second-order convergence; explicit damping did not exactly conserve it. This is a very limited thermodynamic reference, not cosmological gas physics.

## 6.3 Recorded seven-experiment overview

| ID | Purpose | Most relevant archive-reported observation |
|:--|:--|:--|
| exp01 | Conservative averaging identity | Rational-arithmetic residual zero in test cases; two atoms $K:1\to0$ |
| exp02 | Restricted symplectic no-go | Duplication defect zero; nontrivial averaging has nonzero defect |
| exp03 | Sheet defect / derivative order | Counterexample with $D^3F=0$ yet nonzero PL defect |
| exp04 | 1D sheet baselines | Approximation and singularity scaling; 1D 2-form is vacuous |
| exp05 | 2D sheet in 4D phase space | Reported near-first-order PL two-form defect, independent of $t$ in selected family; caustics tracked separately |
| exp06 | Monitor and graded-remap comparisons | Grading helps with freshly known values; reinterpolation may worsen error |
| exp07 | GENERIC oscillator | Energy-corrected implicit prototype and second-order numerical behavior |

### The decisive exp06 comparison

At 128-by-128 samples for a prescribed 2D Gaussian-like test sheet, the archived global RMS errors are:

| Arm | How sampled | RMS error |
|:--|:--|--:|
| A | Uniform mesh, exact values at its nodes | **0.0047227683** |
| B | Graded mesh, **fresh exact values** at its nodes | **0.0017542201** |
| C | Graded mesh, values reconstructed from Arm A | **0.0056246100** |

So the ideal graded geometry reduced this error by approximately 63%, while **remapping an existing approximation made it roughly 19% worse than Arm A**. Grading alone cannot create missing information; representation transfer must be part of the method's accuracy analysis. The source explicitly identifies this as prescribed grading; it does **not** establish a measured OT speedup over a competitive moving-sheet solver.

---

# 7. Reconciliation, contradictions, and unresolved mathematical issues

## 7.1 What is complementary, not contradictory

Fable's smooth label-space reparameterization with action-aware chart reconstruction and DeepSeek's semi-discrete OT **averaging/coarsening** are mathematically different operators. Consequently, DeepSeek's no-go theorem does not rule out Fable's construction. In turn, action preservation of a 1D reconstructed carrier does **not** refute DeepSeek's theorem about the global mass-weighted nodal symplectic form.

**Four distinct guarantees must always be named:** (i) physical pushforward mass measure; (ii) Lagrangian two-form/closed one-form on the represented sheet; (iii) action periods around cycles; (iv) canonical symplecticity of a map on an entire finite-dimensional nodal state space. These are not interchangeable.

The two experiments use different monitors and different information sets. A fair head-to-head must use identical exact reference solutions, equal node budgets, time integration, error norms, and recorded compute cost.

## 7.2 The Fable monitor-exponent issue — correction required

Fable's manuscript proposes, in its Section 3, an $L^1$ monitor formula

$$
M\propto\|C\|^{d/(d+3)}
$$

but presents an optimization objective of the form

$$
\min\int\|C\|h^{3-d}\,dq
\quad\text{subject to}\quad\int h^{-d}\,dq=N.
$$

The displayed objective does **not** give the claimed exponent. For $d\ne3$, formal variation gives $h^3\propto\|C\|^{-1}$, hence $M\sim h^{-d}\propto\|C\|^{d/3}$; at $d=3$ the written integrand is independent of $h$ and gives no useful Euler–Lagrange allocation rule. The claimed $d/(d+3)$ exponent could instead arise from an objective proportional to $\int\|C\|h^3\,dq$, but this would require justifying **why that is the correct global error functional** rather than inserting it to obtain a desired exponent.

**Status: unresolved derivation inconsistency, not a disproof of all action monitors.** Establish whether the objective sums per-edge errors, per-cell integrated error, an $L^1$ density, an $L^2$ density or a maximum-error objective, and keep the element/edge count and Jacobian units consistent. Check periodic/anisotropic mesh quality assumptions. Do not transfer DeepSeek's scalar $L^2$ interpolation exponent to Fable's action objective without a fresh derivation.

## 7.3 Other warnings that must survive every context reset

- **1D two-form diagnostic is vacuous.** Use periods and action area in 1D; use $d\ge2$ for a nontrivial $F^*\omega$ defect.
- **Caustic indicators differ from two-form defects.** Small geometric defect does not imply no folding; monitor the spatial Jacobian and conditioning.
- **Global chart gluing remains open.** Local generating functions can fail across fold caustics; overlapping charts need transition functions, matching and period/cohomology conditions.
- **No unrestricted exactness claim.** Changing node count/topology can lose information, and conventional positive averaging violates the nodal symplectic condition.
- **Fable's stability proof is conditional.** The moving-frame reconstruction Lipschitz assumption is not yet generally established; observed remap-count behavior is not long-time proof.
- **Self-gravity is not tested.** A prescribed EdS potential is not equivalent to self-consistent periodic Vlasov–Poisson with sheet density deposition and feedback on the field.
- **No validated performance win.** Mathematical complexity/gain proxies are not wall-clock speedups or equal-error memory comparisons.
- **GENERIC degeneracy has a domain of validity.** Open systems, radiative losses, chemistry, shock entropy and cosmological work need proper source/flux accounting.
- **Published priority is unknown.** Existing ColDICE, adaptive phase-space elements, OT moving meshes, geometric optics and structure-preserving integration are substantial prior art.
- **No claims from earlier unverified DeepSeek drafts should be carried forward** without the Mission 01 corrections.

## 7.4 Consolidated status ledger

| Claim/result | Current status | Evidence and caveat |
|:--|:--|:--|
| Exact Hamiltonian flow preserves canonical symplectic form | Established under regularity assumptions | Standard theorem, not new |
| Exact initially Lagrangian sheet remains Lagrangian | Established/conditional on smooth flow and initial state | Continuous statement |
| Smooth relabeling plus pulled-back mass leaves physical measure unchanged | Established elementary identity | Not automatically true of interpolated discrete fields |
| Generic positive-weight linear averaging is exactly symplectic | **Disproved** except trivial copying/permutation under specified form | DeepSeek Mission 01 theorem |
| Averaging decreases resolved bulk kinetic energy by dispersion | Algebraically established under stated weights | DeepSeek exp01 and proof |
| P1 interpolation may create a two-form defect | Established for tested setting; derivation needs review | DeepSeek exp03/05 |
| Action-corrected 1D remap retains selected action periods | Derived/reported and numerically supported | Fable AC family; check full theorem |
| Fable local generating-function chart has zero intrinsic $F^*\omega$ | Conditional local-chart mathematical construction | Global conformity/caustics unresolved |
| Specific OT monitor exponent and gain from Fable manuscript | **Needs correction** | Equation/objective mismatch above |
| 2D graded exact-node sampling improves error | Numerically supported in supplied test | DeepSeek exp06; ideal-node oracle only |
| 2D remapping graded nodes from uniform approx improves error | **Disproved in supplied test** | DeepSeek exp06 Arm C worse than A |
| Fable AC has global 3D cosmological convergence | **Open / not shown** | No self-gravity, 3D, or unrestricted stability proof |
| GENERIC oscillator can use compatible energy/entropy operators | Established framework; reference numerical result | DeepSeek exp07; not astrophysical gas |
| Novelty relative to full literature | **Open** | Sources mostly checked at metadata/abstract level |
| Integrated SHAI-HULUD numerical method beats baseline CHUÍ | **Not demonstrated** | Requires fair runtime/accuracy/physics benchmarks |

---

# 8. Research programme and validation gates

A mathematically excellent idea may still fail computationally. Each milestone must produce a narrow, falsifiable result **before** the next dependency is introduced.

## Gate 0 — Archive, reconcile and independently check mathematics

**Deliverables:** current dossier; preserved original ZIPs; action/OT notation map; corrected monitor proof; restricted no-go proof independently checked; proof ledger with links to exact code/tests. **Pass criterion:** no active contradiction survives between equations, theorem assumptions and code. Clearly mark open claims.

## Gate 1 — Fair 1D reconstruction challenge

Compare action-corrected, cubic/quintic interpolation, monotone OT label redistribution, conservative averaging where relevant, and a non-moving refinement baseline. Match node budgets and potential/time-integrator. Test smooth twist (where adaptation may not help), spiral/hairpin formation, periodic action periods, forced chaos and multiple repeated remaps. Measure **full phase-space error, separated normal/tangential error, action period, mass-moment error, repeated-remap drift, CPU time and memory**. Include equal work as well as equal $N$.

**Pass criterion:** action-aware reconstruction provides a repeatable, physically relevant improvement in a specified regime without unacceptable errors elsewhere. Negative cases are documented rather than hidden.

## Gate 2 — 2D sheets and caustic-safe charts

Test 2D label manifolds in 4D phase space, beginning with known exact gradient sheets. Develop chart transition functions/generating functions over a fold, compatible action periods, and overlap/gluing residuals. Separate orientation/caustic metrics from $F^*\omega$ defects. Compare unconstrained high-order interpolation, local generating functions and constrained projection.

**Pass criterion:** controlled approximation across a specified multistream fold, verified 2-form and action residuals **plus** full physical approximation error. A conditional theorem or counterexample on multi-chart gluing is an acceptable research output.

## Gate 3 — Three-dimensional geometry, monitors, h/r adaptation

Implement a 3D label-sheet defect experiment on tetrahedra; verify all three independent components of $F^*\omega$, test P1 defect scaling and special exact identities. Compare ordinary refinement ($h$), node redistribution ($r$), local polynomial order ($p$), and combined $hp/r$ choices. Re-derive and calibrate the **defect-specific** OT monitor. Add anisotropic/shape-conditioning metrics and memory budgets.

**Pass criterion:** proven or carefully delimited 3D geometric identities plus convergence/cost measurements; no blanket promise of $O(N\log N)$ Laguerre geometry or globally stable topology changing.

## Gate 4 — Self-consistent gravity and cosmology

Implement minimal periodic 1D/2D self-gravitating Vlasov–Poisson first; later test three-dimensional cosmological initial conditions. Coupling requires density from sheet volumes, force from common potential with acceptable curl/structure properties, momentum/energy diagnostics, appropriate KDK time-centering, cosmological balance checks, force errors and convergence against fixed-sheet and N-body baselines. Benchmark Zel'dovich pancake, two-sine-wave collapse, multistream phase-space structure and halo behavior where resolved.

**Pass criterion:** evidence of better *scientific observables per computational cost* under specified conditions. A visually smoother phase-sheet render is insufficient.

## Gate 5 — Hybrid sheet–particle transfer

Introduce carefully controlled, initially **one-way** sheet release in highly mixed regions. Retain parentage and exact mass ledger, sample velocity/position moments, quantify stochastic noise and gravitational potential change, and explicitly record lost sheet information. Reject reversible sheet reconstruction from arbitrary released particles until independently justified.

**Pass criterion:** robust force/mass/structure observables in transitions and a measured advantage over continuously refining everything.

## Gate 6 — SPICE / GENERIC / gas coupling

After the collisionless foundation is stable, construct SPICE operator contracts, finite-dimensional GENERIC baselines, discrete thermodynamic balances and then a compatible gas solver. Study appropriate reversible/irreversible splitting, open-radiative energy/entropy budgets, chemistry and eventual moving-Laguerre hydrodynamics. Keep physical entropy production separate from numerical transfer dissipation.

**Pass criterion:** independently tested thermodynamic and conservative properties in physically relevant reference flows, not just a damped oscillator.

## Gate 7 — Production CHUÍ and other DUNE modules

Only after previous gates: C++ port, memory/MPI governor, reproducible checkpoints, thread-safe geometry operations, rich field diagnostics, benchmarks across CPUs/MPI, predictive refinement (Navigator), resource policies (Mentat), adjoints (Bene Gesserit) and UQ ensembles (Golden Path). Maintain the standard CHUÍ path as a supported control condition.

**Pass criterion:** benchmarked, documented, selectively enabled scientific value; no regression when the experimental subsystem is disabled.

---

# 9. DeepSeek's prioritized open questions (source Q1–Q10)

The DeepSeek archive provides more exact experimental protocols in `reports/next_research_questions.md`; retain these IDs when discussing follow-up work.

| Priority | ID | Precise question | Important status |
|:--|:--|:--|:--|
| P0 | Q1 | Does the 2-form defect identity extend componentwise to 3D tetrahedra? | **Not tested**; predicted in a special gradient family |
| P0 | Q2 | Is a $\|D^3S\|$-based defect monitor better than a $\|D^2S\|$ solution monitor on its own metric? | **Hypothesis; not yet numerically demonstrated** |
| P0 | Q3 | Can finite-set/piecewise nonlinear coarsening preserve a meaningful symplectic structure beyond the smooth rank obstruction? | Open; precise bracket/state-space required |
| P1 | Q4 | How do dispersion and geometric defect accumulate under repeated remaps? | Open beyond restricted reported tests |
| P1 | Q5 | Does OT outperform an equal-work tensor-graded mesh rather than a weak uniform baseline? | Open |
| P1 | Q6 | Does the correct Layzer–Irvine balance survive self-gravity plus expansion and remap? | Open, requires full coupled test |
| P1 | Q7 | Can a sheet–gas GENERIC coupling retain both discrete degeneracies? | Open, high-cost research |
| P2 | Q8 | What is a sharp shape-dependent lower bound on the defect? | Open |
| P2 | Q9 | How should anisotropic/AMR quality and MPI-local OT be implemented? | Open |
| P2 | Q10 | What does a complete geometric-integration/OT/phase-sheet novelty audit reveal? | Open |

**Additional immediate action, independent of Q1–Q10:** directly benchmark Fable's action-corrected reconstruction against DeepSeek's conventional remapping with **the same reference state and error norms**. That is the most useful synthesis of the two archives.

---

# 10. Experimental and software specifications for future continuation

## 10.1 Mathematical operator contract (planned SPICE interface)

For each operator, record:

- domain and codomain of the physical state and the discrete geometry;
- variables and units, including cosmological time convention;
- source and target mass measures;
- preconditions (regularity, positivity, chart admissibility, geometry quality);
- guaranteed versus monitored properties (mass, momentum, energy/balance, period, two-form, entropy, positivity);
- order of accuracy, consistency assumptions, required boundary/periodicity conditions;
- numerical failure modes and recommended fallback;
- memory allocations, asymptotic work and inter-rank communication requirements;
- deterministic restart/reproducibility metadata, algorithm/version ID;
- independent reference tests and acceptable error threshold.

For representation transfer, return an **invariant/defect ledger**, not only new arrays. Some mappings are irreversible or stochastic; such outcomes should be explicit in the returned metadata.

## 10.2 Baseline evaluation metrics

Use absolute and normalized errors for: global mass, component masses, linear momentum, gravitational force, full $L^2/L^\infty$ sheet geometry, normal/tangential error, action loop periods, pulled-back two-form norm, spatial Jacobian/orientation, density and $P(k)$, halo statistics where applicable, energy/Layzer–Irvine residual, physical versus numerical entropy, positivity and volume/geometric conservation. Cost: elapsed time, steps, time per deposited element, peak RAM, MPI exchange and strong/weak scaling.

Report exact/analytic reference versus extrapolated high-resolution numerical reference separately. Never call a calculated geometric gain proxy a speedup without measured wall time.

## 10.3 Scientific reproducibility requirements

- Fixed seeds and deterministic mesh-generation options for reference experiments.
- Complete input parameters (cosmological $a$, density normalization, external/self-consistent potential, solver tolerance, monitor smoothing scale).
- Exact code commit/source checksum and software environment.
- Distinguish a project-script output from an independently reproduced calculation.
- Persist failed hypotheses and discarded ideas.
- Explicitly log when an adaptation was rejected by an invariant, positivity, memory or error-budget gate.
- Keep generated research files outside production CHUÍ directories until accepted by an integration review.

---

# 11. Reproducing the supplied research archives

## 11.1 Fable

Extract `shai_hulud.zip` and, within `shai_hulud/prototype/`, install compatible `numpy`, `scipy`, `sympy`, `matplotlib` versions. The README provides the sequence:

```bash
python3 verify_propositions.py
python3 experiments_1d.py
python3 experiments_2d.py
python3 make_tables.py
python3 make_figures.py
```

The full 1D experiment suite is computationally heavier than a smoke test; run targeted jobs first. LaTeX sources are in `manuscript/`; use the included compiled `shai_hulud.pdf` for the submitted manuscript. The README reports 11/11 verification checks, but those checks do **not** certify every theorem or novelty claim.

## 11.2 DeepSeek

Extract `shai-hulud-lab(2).zip`. From its root, configure Python dependencies and run (e.g. in PowerShell):

```powershell
$env:PYTHONPATH = "experiments"
python experiments/exp01_remap_identity.py
python experiments/exp02_symplectic_nogo.py
python experiments/exp03_lagrangian_defect.py
python experiments/exp04_sheet_1d.py
python experiments/exp05_sheet_2d.py
python experiments/exp06_adaptation_2d.py
python experiments/exp07_generic_oscillator.py
```

Expected JSON outputs exist in `experiments/results/`. Read `reports/mission_01.md` **instead of** treating `inputs/deepseek_01_unverified.txt` or `inputs/deepseek_02_unverified.txt` as validated final science.

## 11.3 Verification provenance

The prior ChatGPT discussion reported a limited rerun of four Fable checks and six DeepSeek scripts. **This dossier is primarily a detailed source-grounded archival synthesis, not a fresh independent re-proof or a full rerun of every experiment.** To upgrade a scientific claim to independently verified, preserve the exact command, environment, output and audit of the underlying mathematics.

---

# 12. Selected literature to check in detail

The following are real works listed in DeepSeek's `research/sources.md`, which reports bibliographic verification at DOI/arXiv metadata level. **Metadata confirmation is not a full-text theorem audit.** These are priority sources for a later expert literature review:

1. Abel, Hahn & Kaehler (2012), *Tracing the dark matter sheet in phase space*, DOI `10.1111/j.1365-2966.2012.21754.x`.
2. Hahn & Angulo (2015), *An adaptively refined phase-space element method for cosmological simulations and collisionless dynamics*, DOI `10.1093/mnras/stv2304`.
3. Sousbie & Colombi (2016), *ColDICE: A parallel Vlasov–Poisson solver using moving adaptive simplicial tessellation*, DOI `10.1016/j.jcp.2016.05.048`.
4. Brenier (1991), *Polar factorization and monotone rearrangement of vector-valued functions*, DOI `10.1002/cpa.3160440402`.
5. Kitagawa, Mérigot & Thibert (2019), *Convergence of a Newton algorithm for semi-discrete optimal transport*, DOI `10.4171/JEMS/889`.
6. McRae, Cotter & Budd, *Optimal-transport-based mesh adaptivity on the plane and sphere using finite elements*, arXiv `1612.08077`.
7. Budd, Russell & Walsh, *Alignment properties of Monge–Ampère based mesh redistribution*, arXiv `1402.5453`.
8. Grmela & Öttinger (1997), *Dynamics and thermodynamics of complex fluids. I*, DOI `10.1103/PhysRevE.56.6620`.
9. Kraus & Hirvijoki (2017), *Metriplectic integrators for the Landau collision operator*, arXiv `1707.01801`.
10. Avelino & Barreira (2012), *Layzer–Irvine equation: New perspectives and the role of interacting dark energy*, DOI `10.1103/PhysRevD.85.063504`.
11. Krah et al. (2026), *A hybrid semi-Lagrangian flow mapping approach for Vlasov systems*, arXiv `2601.21668`.
12. Ye et al. (2025), *An adaptive symplectic integrator for gravitational dynamics*, arXiv `2507.14881`.

Also audit the geometric-optics/wavefront generating-function literature, Hamilton–Jacobi interpolation and discrete exterior calculus before any originality claim regarding action-aware remeshing. Fable's manuscript bibliography contains additional references; consult both original archives rather than treating this short reading list as exhaustive.

---

# 13. Provenance, original archive checksums, and source index

**As-of date:** 16 November 2026. The supplied archives are preserved as independent research artifacts and should not be overwritten by a newly synthesized method without version control.

| Artifact | Description | SHA-256 |
|:--|:--|:--|
| `shai_hulud.zip` | Fable manuscript, 1D/2D prototypes, data | `67a34da6f43a893cb6f574e7bd12dbbb213d7fd8bc23b9713742c7db0aa7cddc` |
| `shai-hulud-lab(2).zip` | DeepSeek formal audit, seven scripts and reports | `df6066f5e9a5ed9ed2f55d248e2d9f6960c67dfd72bfc837717596912fb7b108` |
| `chatgpt-export-2026-11-16T11-58-15-556Z.zip` | Export of the earlier project-idea discussion branch | `cd608ae6eeaeafef10bb6b188c12e1462ee3e2b2e421b5aef1fd00d2ddb20389` |

## Source hierarchy

- **Historical design intent:** this CHUÍ-HULUD conversation and the exported project-idea branch.
- **Fable's actual mathematical claims/results:** `shai_hulud.zip/shai_hulud/manuscript/`, `proof_ledger.md`, `results/`.
- **DeepSeek's corrected final position:** `shai-hulud-lab(2).zip/reports/mission_01.md`, `research/`, `experiments/results/`.
- **Unverified material:** the earlier DeepSeek drafts in `inputs/`, and any headline novelty or correctness claim not backed by a complete proof or a fair independent numerical test.

A new agent or human reader should start here, then read Fable's manuscript and DeepSeek Mission 01 **before** modifying code or claiming a theorem.

---

# 14. Continuation instruction for a new AI session

The following text can be copied into a future session, with the dossier and both original archives attached:

> **Resume Project DUNE / SHAI-HULUD.** SHAI-HULUD is intended to be a genuine structure-aware numerical evolution method for cold collisionless phase-space sheets, not an administrator of existing solvers. The source context is `SHAI_HULUD_Project_Dossier_2026-11-16.md`, `shai_hulud.zip` (Fable action-aware reconstruction) and `shai-hulud-lab(2).zip` (DeepSeek discrete symplectic no-go and falsification audit). Read their original proof ledgers and experiment results before planning anything. The immediate priority is to reconcile the invalid/unclear action-monitor optimization, fairly benchmark action-corrected versus conventional remapping under common initial data, and investigate globally compatible generating-function charts across 2D caustics. Distinguish physical pushforward-mass conservation, Lagrangian two-form preservation, Liouville periods and full finite-dimensional symplecticity. Do not claim a working self-gravitating 3D solver, GENERIC gas coupling, novelty, or performance speedup without new evidence. Preserve negative results and keep production CHUÍ unchanged.

## First question to ask after loading the files

**What is the smallest nontrivial mathematical and numerical experiment that would show action-aware adaptation actually improves an *evolving*, self-consistent phase-sheet approximation after remapping—rather than merely retaining an invariant while sacrificing physical accuracy?**

That question, not code volume, should determine the next research step.

---

# 15. Final status as of this dossier

**What we have:** a coherent long-term experimental architecture, a precise central mathematical challenge, one action-aware reconstruction proposal with promising 1D and restricted 2D results, a rigorous-looking restricted symplectic obstruction for averaging, numerical counterexamples, useful phase-sheet defect diagnostics and thermodynamic reference calculations.

**What we do not have:** a globally valid new adaptive Vlasov–Poisson scheme, proven unrestricted remapping stability, 3D coupled cosmology, verified novelty, or a demonstrated accuracy-per-walltime advantage over established sheet/N-body methods.

**The research value so far is real but carefully bounded.** We now know which naive remaps cannot preserve certain geometric structures, which geometric indicators are misleading, why adaptive sampling may fail without accurate reconstruction, and what a more promising action-aware alternative should be tested against. These conclusions are worth preserving even if the grand unified Maker never becomes practical.

> **Permanent project principle:** *The Maker earns its name through mathematical behavior demonstrated on physical test problems—not through the number of exotic numerical techniques it contains.*
